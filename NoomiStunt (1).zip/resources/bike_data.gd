class_name BikeData
## Static data for bikes and customization palettes.

const BIKES := {
	"noomi125": {
		"name": "NOOMI 125",
		"price": 0,
		"mass": 105.0,
		"engine_f": 1650.0,
		"top_speed": 20.0,
		"wheelie": 1.0,
		"grip": 1.0,
		"accel_stat": 0.75,
		"speed_stat": 0.7,
		"weight_stat": 0.55,
		"wheelie_stat": 0.7,
	},
	"rocket190": {
		"name": "ROCKET 190",
		"price": 500,
		"mass": 125.0,
		"engine_f": 2150.0,
		"top_speed": 26.0,
		"wheelie": 0.8,
		"grip": 1.05,
		"accel_stat": 1.0,
		"speed_stat": 1.0,
		"weight_stat": 0.85,
		"wheelie_stat": 0.5,
	},
	"cobra110": {
		"name": "COBRA 110",
		"price": 1200,
		"mass": 92.0,
		"engine_f": 1500.0,
		"top_speed": 18.5,
		"wheelie": 1.3,
		"grip": 1.12,
		"accel_stat": 0.6,
		"speed_stat": 0.55,
		"weight_stat": 0.35,
		"wheelie_stat": 1.0,
	},
}

const PLASTIC_COLORS := [
	Color(0.85, 0.25, 0.12), Color(0.10, 0.45, 0.90), Color(0.95, 0.65, 0.05),
	Color(0.10, 0.65, 0.30), Color(0.85, 0.15, 0.45), Color(0.90, 0.90, 0.92),
	Color(0.10, 0.10, 0.14), Color(0.55, 0.20, 0.75),
]

const WHEEL_STYLES := ["Стандарт", "Золото", "Толстые"]
const BAR_STYLES := ["Кроссбар", "Низкий"]
const STICKERS := ["Нет", "Звезда", "Молния", "Полосы"]

const HELMET_COLORS := [
	Color(0.92, 0.92, 0.95), Color(0.15, 0.15, 0.18), Color(0.85, 0.25, 0.12),
	Color(0.10, 0.45, 0.90), Color(0.95, 0.65, 0.05), Color(0.10, 0.65, 0.30),
]

const GEAR_COLORS := [
	Color(0.80, 0.25, 0.10), Color(0.12, 0.40, 0.85), Color(0.90, 0.70, 0.10),
	Color(0.10, 0.60, 0.30), Color(0.45, 0.45, 0.55), Color(0.85, 0.15, 0.40),
]
