extends RigidBody3D
## Pitbike physics: planar rigid body (X = travel, Y = up) with pitch-only
## rotation, two raycast wheels with spring suspension, drive/brake friction,
## wheelie/stoppie, drift (burnout), air rotation (flips), landing analysis.

signal landed(impact: float)
signal event_flushed      # wheelie ended cleanly
signal flip_done(deg: float)

const REST_LEN := 0.38
const WHEEL_R := 0.32
const RAY_LEN := REST_LEN + WHEEL_R
const ANCHOR_REAR := Vector3(-0.56, -0.05, 0)
const ANCHOR_FRONT := Vector3(0.60, -0.05, 0)
const AXLE_REST_Y := -0.268

var cfg: Dictionary
var engine_f := 1650.0
var top_speed := 20.0
var lean_t := 95.0
var grip_stat := 1.0
var wheelie_stat := 1.0
var c_drag := 4.0

var grounded_r := false
var grounded_f := false
var comp_r := 0.0
var comp_f := 0.0
var load_r := 0.0
var load_f := 0.0
var norm_r := Vector3.UP
var norm_f := Vector3.UP
var contact_r := Vector3.ZERO
var contact_f := Vector3.ZERO
var surf_r := "dirt"
var surf_f := "dirt"

var pitch := 0.0
var ang_z := 0.0
var flip_accum := 0.0     # radians accumulated in air
var air := false
var air_time := 0.0
var takeoff_y := 0.0
var max_air_h := 0.0
var _was_air := false
var _prev_vy := 0.0
var _prev_y := 0.0

var burnout := 0.0        # drift/wheelspin 0..1
var wheel_spin := 0.0     # rad/s for visuals
var wheelie_time := 0.0
var stoppie_time := 0.0
var wheelie_active := false
var stoppie_active := false

var controls_enabled := true
var input := {"gas": 0.0, "bf": 0.0, "br": 0.0, "lean": 0.0, "wheelie": false, "drift": false, "flip": false}

var refs := {}            # visual nodes from builders
var yaw_node: Node3D      # bike visual yaw (whip / 360)
var whip_yaw := 0.0
var spin_yaw := 0.0
var spin_left := 0.0      # remaining 360 spin seconds
var spin_done_flag := false
var _crash_latched := false
var _v_long_cache := 0.0

func setup(stats: Dictionary, visual_root: Node3D, visual_refs: Dictionary) -> void:
        cfg = stats
        mass = float(stats["mass"])
        engine_f = float(stats["engine_f"])
        top_speed = float(stats["top_speed"])
        wheelie_stat = float(stats["wheelie"])
        grip_stat = float(stats["grip"])
        c_drag = engine_f / (top_speed * top_speed)
        lean_t = 95.0 * wheelie_stat
        refs = visual_refs
        yaw_node = visual_root
        axis_lock_linear_z = true
        axis_lock_angular_x = true
        axis_lock_angular_y = true
        contact_monitor = false
        can_sleep = false
        var pm := PhysicsMaterial.new()
        pm.friction = 0.9
        pm.bounce = 0.0
        physics_material_override = pm

func _ready() -> void:
        var cs := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = Vector3(1.05, 0.42, 0.30)
        cs.shape = shape
        cs.position = Vector3(0.0, 0.02, 0)
        add_child(cs)

func _integrate_forces(_state: PhysicsDirectBodyState3D) -> void:
        pass

func _physics_process(dt: float) -> void:
        _read_input()
        var com := to_global(center_of_mass)
        _prev_vy = linear_velocity.y
        _prev_y = global_position.y
        ang_z = angular_velocity.z

        # ---------- wheel rays (along bike local down)
        var down := -global_transform.basis.y
        var hit_r := _ray(to_global(ANCHOR_REAR), down, com)
        var hit_f := _ray(to_global(ANCHOR_FRONT), down, com)

        grounded_r = hit_r.size() > 0
        grounded_f = hit_f.size() > 0
        air = not (grounded_r or grounded_f)

        # ---------- suspension
        var suspension := 0.0
        if grounded_r:
                suspension = _suspension(hit_r, down, com, dt, true)
        if grounded_f:
                suspension += _suspension(hit_f, down, com, dt, false)

        # ---------- pitch / flip bookkeeping
        var fwd := global_transform.basis.x
        pitch = atan2(fwd.y, fwd.x)
        if pitch > PI:
                pitch -= TAU
        if pitch < -PI:
                pitch += TAU
        if air:
                air_time += dt
                flip_accum += ang_z * dt
                if air_time == dt:
                        takeoff_y = _prev_y
                max_air_h = maxf(max_air_h, global_position.y - takeoff_y)
        else:
                if _was_air:
                        _on_landing()
                air_time = 0.0
                flip_accum = 0.0
                max_air_h = 0.0
        _was_air = air

        # ---------- drive / brake / grip
        if grounded_r:
                var v_long := _tangential_speed(hit_r, com)
                _traction(hit_r, hit_f, v_long, com)
                _v_long_cache = v_long
        else:
                _v_long_cache = 0.0
                _traction(hit_r, hit_f, 0.0, com)

        # ---------- air drag
        var v := linear_velocity
        apply_force(-v * v.length() * c_drag * 0.02)

        # ---------- rotation control
        _rotation_control(dt, _v_long_cache)

        # ---------- burnout / drift
        var want_bo: bool = input["drift"] and grounded_r and input["gas"] > 0.2
        burnout = clampf(burnout + (1.6 * dt if want_bo else -2.5 * dt), 0.0, 1.0)

        # ---------- wheel spin visual
        var target_spin := 0.0
        var v_long := _v_long_cache
        if grounded_r:
                target_spin = v_long / WHEEL_R
        if want_bo or (input["gas"] > 0.4 and air):
                target_spin += 22.0 * input["gas"] * (1.0 + burnout)
        wheel_spin = lerpf(wheel_spin, target_spin, 0.3)

        # ---------- wheelie / stoppie state
        wheelie_active = grounded_r and not grounded_f and pitch > 0.18 and v_long > 1.0
        stoppie_active = grounded_f and not grounded_r and pitch < -0.15 and v_long > 1.5
        if wheelie_active:
                wheelie_time += dt
        else:
                wheelie_time = 0.0
        if stoppie_active:
                stoppie_time += dt
        else:
                stoppie_time = 0.0

        # ---------- audio params
        AudioMan.set_engine(true)
        AudioMan.load_a = input["gas"]
        var rpm_n := clampf(absf(_v_long_cache) / top_speed, 0.0, 1.0)
        if air and input["gas"] > 0.2:
                rpm_n = maxf(rpm_n, 0.55 + 0.3 * float(input["gas"]))
        AudioMan.rpm = clampf(rpm_n * 0.85 + 0.1 + burnout * 0.25, 0.0, 1.0)
        AudioMan.skid_level = clampf(burnout * (0.6 + 0.4 * float(input["gas"])) + (0.5 if (float(input["br"]) > 0.6 and absf(_v_long_cache) > 6.0 and grounded_f) else 0.0), 0.0, 1.0)

        # ---------- crash by pitch (loop-out)
        if not _crash_latched and grounded_r and pitch > 1.45:
                _crash_latched = true
                get_tree().call_group("game", "on_crash", "ПЕРЕЛЕТ НАЗАД")
        if not _crash_latched and grounded_f and pitch < -1.45:
                _crash_latched = true
                get_tree().call_group("game", "on_crash", "ПЕРЕЛЕТ ВПЕРЁД")

        # ---------- safe checkpoint
        if grounded_r and grounded_f and absf(pitch) < 0.3 and absf(_v_long_cache) < 12.0:
                _safe_store()

func _safe_store() -> void:
        var g: Node = get_tree().get_first_node_in_group("game")
        if g and g.has_method("store_safe"):
                g.store_safe(global_transform)

func _read_input() -> void:
        if controls_enabled:
                input["gas"] = Input.get_action_strength("gas")
                input["bf"] = Input.get_action_strength("brake_f")
                input["br"] = Input.get_action_strength("brake_r")
                input["lean"] = Input.get_action_strength("lean_l") - Input.get_action_strength("lean_r")
                input["wheelie"] = Input.is_action_pressed("wheelie")
                input["drift"] = Input.is_action_pressed("drift")
                input["flip"] = Input.is_action_pressed("t_flip")
        else:
                input["gas"] = 0.0
                input["bf"] = 0.0
                input["br"] = 0.0
                input["lean"] = 0.0
                input["wheelie"] = false
                input["drift"] = false
                input["flip"] = false

func _ray(from: Vector3, down: Vector3, com: Vector3) -> Dictionary:
        var space := get_world_3d().direct_space_state
        var q := PhysicsRayQueryParameters3D.create(from, from + down * RAY_LEN, 1, [get_rid()])
        var hit := space.intersect_ray(q)
        if hit.has("collider") and hit["collider"] is Object and (hit["collider"] as Object).has_meta("surf"):
                hit["surf"] = (hit["collider"] as Object).get_meta("surf")
                hit["grip"] = (hit["collider"] as Object).get_meta("grip", 1.0)
        return hit

func _suspension(hit: Dictionary, down: Vector3, com: Vector3, _dt: float, rear: bool) -> float:
        var contact: Vector3 = hit["position"]
        var dist: float = from_to_dist(to_global(ANCHOR_REAR if rear else ANCHOR_FRONT), contact)
        var comp := clampf(RAY_LEN - dist, 0.0, 0.30)
        var up_n := -down
        var point_vel := linear_velocity + angular_velocity.cross(contact - com)
        var vel_up := point_vel.dot(up_n)
        var k := 5200.0 * (mass / 105.0)
        var damp := 380.0 * (mass / 105.0)
        var force := k * comp - damp * vel_up
        force = clampf(force, 0.0, 3.2 * k * 0.30)
        apply_force(up_n * force, contact - com)
        if rear:
                comp_r = comp
                load_r = force
                norm_r = hit["normal"]
                contact_r = contact
                surf_r = hit.get("surf", "dirt")
        else:
                comp_f = comp
                load_f = force
                norm_f = hit["normal"]
                contact_f = contact
                surf_f = hit.get("surf", "dirt")
        # wheel visual position
        var wkey := "wheel_rear" if rear else "wheel_front"
        if refs.has(wkey):
                var wc := (dist - WHEEL_R)
                var anchor := ANCHOR_REAR if rear else ANCHOR_FRONT
                refs[wkey]["holder"].position = Vector3(anchor.x, anchor.y - wc, 0)
        return force

func from_to_dist(a: Vector3, b: Vector3) -> float:
        return (b - a).length()

func _tangent(n: Vector3) -> Vector3:
        return Vector3(n.y, -n.x, 0).normalized()

func _tangential_speed(hit: Dictionary, com: Vector3) -> float:
        var contact: Vector3 = hit["position"]
        var tn := _tangent(hit["normal"])
        var pv := linear_velocity + angular_velocity.cross(contact - com)
        return pv.dot(tn)

func _traction(hr: Dictionary, hf: Dictionary, v_long: float, com: Vector3) -> bool:
        var any := false
        # rear wheel: drive + rear brake, traction-clamped
        if hr.size() > 0:
                any = true
                var contact: Vector3 = hr["position"]
                var tn := _tangent(hr["normal"])
                var mu := Assets.surf_grip(surf_r) * grip_stat * (1.0 - 0.62 * burnout)
                var max_f := mu * load_r
                var pv := linear_velocity + angular_velocity.cross(contact - com)
                var slip := pv.dot(tn)
                var drive: float = float(input["gas"]) * engine_f * clampf(1.0 - slip / top_speed, 0.0, 1.0)
                if slip < 0.0:
                        drive = float(input["gas"]) * engine_f
                var total := 0.0
                if float(input["br"]) > 0.05:
                        total = clampf(-signf(slip) * float(input["br"]) * 1400.0, -max_f, max_f)
                apply_force(tn * total, contact - com + Vector3(0, 0.25, 0))
                # drive applied near COM height -> minimal unwanted pitch torque
                var drive_c := clampf(drive, -max_f, max_f)
                apply_force(tn * drive_c, contact - com + Vector3(0, 0.38, 0))
                # rolling resistance
                apply_force(tn * -signf(slip) * 30.0 * float(input["gas"] == 0.0), contact - com)
        # front wheel: front brake + rolling resistance, traction-clamped
        if hf.size() > 0:
                any = true
                var contact2: Vector3 = hf["position"]
                var tn2 := _tangent(hf["normal"])
                var mu2 := Assets.surf_grip(surf_f) * grip_stat
                var max_f2 := mu2 * load_f
                var pv2 := linear_velocity + angular_velocity.cross(contact2 - com)
                var slip2 := pv2.dot(tn2)
                var total2 := 0.0
                if float(input["bf"]) > 0.05:
                        total2 = clampf(-signf(slip2) * float(input["bf"]) * 2000.0, -max_f2, max_f2)
                total2 += -signf(slip2) * 25.0 * float(input["gas"] == 0.0)
                apply_force(tn2 * clampf(total2, -max_f2, max_f2), contact2 - com + Vector3(0, 0.22, 0))
        return any

func _rotation_control(dt: float, v_long: float) -> void:
        var tz := 0.0
        if not air:
                tz = 260.0 * (0.0 - pitch) - 55.0 * ang_z
                tz += float(input["lean"]) * lean_t
                if input["wheelie"] and v_long > 2.0 and grounded_r:
                        # dedicated wheelie lift controller (target ~0.5 rad)
                        var lift := clampf(1.0 - pitch / 0.62, 0.0, 1.0)
                        tz += 640.0 * wheelie_stat * lift
                        tz -= ang_z * 30.0
                elif float(input["bf"]) > 0.6 and v_long > 3.5 and float(input["lean"]) < -0.3:
                        # stoppie assist (hold nose down a bit)
                        tz -= 320.0 * clampf(1.0 - absf(pitch) / 0.5, 0.0, 1.0)
        else:
                var has_air_input: bool = absf(float(input["lean"])) > 0.05 or input["flip"]
                if has_air_input:
                        tz = float(input["lean"]) * lean_t * 2.6
                        if input["flip"]:
                                tz += 200.0 * wheelie_stat
                        tz -= ang_z * 2.0
                else:
                        # gentle auto-level so bumps don't send the bike tumbling
                        tz = -ang_z * 4.0 - 18.0 * pitch
        # self-righting nudge when resting upside-down and slow (not while dead)
        if controls_enabled and absf(pitch) > 2.0 and linear_velocity.length() < 2.5:
                tz -= 170.0 * signf(pitch)
        apply_torque(Vector3(0, 0, tz))

var flip_last := 0.0   # |flip_accum| at the moment of landing (before reset)

func _on_landing() -> void:
        flip_last = absf(flip_accum)
        var impact := maxf(0.0, -_prev_vy)
        if impact > 1.0:
                AudioMan.land(impact / 12.0)
        AudioMan.skid_level = maxf(AudioMan.skid_level, clampf(impact / 14.0, 0.0, 0.8))
        if impact > 5.5 and absf(flip_accum) >= TAU * 0.85:
                flip_done.emit(rad_to_deg(absf(flip_accum)))
        landed.emit(impact)

func crash_latch() -> void:
        _crash_latched = true

func clear_crash() -> void:
        _crash_latched = false

func teleport_to(t: Transform3D) -> void:
        await get_tree().physics_frame
        await get_tree().physics_frame
        global_transform = t
        linear_velocity = Vector3.ZERO
        angular_velocity = Vector3.ZERO
        clear_crash()
        whip_yaw = 0.0
        spin_yaw = 0.0
        spin_left = 0.0
        spin_done_flag = false
        burnout = 0.0
        if yaw_node:
                yaw_node.rotation.y = 0.0

func visual_update(dt: float) -> void:
        # wheel spin
        if refs.has("wheel_rear"):
                refs["wheel_rear"]["spin"].rotation.z -= wheel_spin * dt
        if refs.has("wheel_front"):
                refs["wheel_front"]["spin"].rotation.z -= _v_long_cache / WHEEL_R * dt
        # whip yaw
        var want_whip := 0.0
        if Input.is_action_pressed("t_whip") and air:
                want_whip = -0.62
        whip_yaw = lerpf(whip_yaw, want_whip, minf(1.0, dt * 6.0))
        # 360 spin
        if spin_left > 0.0:
                spin_left -= dt
                spin_yaw = minf(spin_yaw + dt * TAU, TAU)
                if spin_left <= 0.0:
                        spin_done_flag = true
        var yaw_total := whip_yaw
        if spin_left > 0.0 or spin_yaw > 0.01:
                yaw_total += wrapf(spin_yaw, -PI, PI)
        if yaw_node:
                yaw_node.rotation.y = yaw_total
        # consume finished/aborted spin state after the landing check had its chance
        if spin_left <= 0.0 and spin_yaw > 0.01:
                if spin_yaw >= TAU * 0.98:
                        spin_yaw = 0.0
                        yaw_node.rotation.y = whip_yaw
                # otherwise keep value until game reads it for the landing verdict

func start_360() -> void:
        if air and spin_left <= 0.0:
                spin_yaw = 0.01
                spin_left = 1.0
                spin_done_flag = false

func yaw_ok_for_landing() -> bool:
        if spin_left > 0.0:
                return false
        if spin_yaw > 0.01 and spin_yaw < TAU * 0.9:
                return false
        return absf(whip_yaw) < 0.25
