extends RefCounted
## VFX: wheel dust, landing bursts, tire marks, all pooled & mobile-friendly.

var root: Node3D
var dust_mat_dirt: ParticleProcessMaterial
var dust_mat_ash: ParticleProcessMaterial
var burst: GPUParticles3D
var marks := []
var mark_i := 0
var enabled := true

const MARK_N := 64

func setup(world_root: Node3D, bike_body: RigidBody3D) -> void:
        root = world_root
        dust_mat_dirt = _dust_process(Color(0.55, 0.42, 0.28))
        dust_mat_ash = _dust_process(Color(0.55, 0.55, 0.58))

        var dq := QuadMesh.new()
        dq.size = Vector2(0.6, 0.6)
        var dmat := _particle_draw()
        dq.material = dmat

        dust_r = GPUParticles3D.new()
        dust_r.amount = 26
        dust_r.lifetime = 0.9
        dust_r.local_coords = false
        dust_r.emitting = false
        dust_r.draw_pass_1 = dq
        dust_r.process_material = dust_mat_dirt
        bike_body.add_child(dust_r)
        dust_r.position = Vector3(-0.56, -0.35, 0)

        dust_f = GPUParticles3D.new()
        dust_f.amount = 16
        dust_f.lifetime = 0.7
        dust_f.local_coords = false
        dust_f.emitting = false
        dust_f.draw_pass_1 = dq
        dust_f.process_material = dust_mat_dirt
        bike_body.add_child(dust_f)
        dust_f.position = Vector3(0.60, -0.35, 0)

        burst = GPUParticles3D.new()
        burst.amount = 26
        burst.lifetime = 0.7
        burst.one_shot = true
        burst.explosiveness = 1.0
        burst.local_coords = false
        burst.emitting = false
        burst.draw_pass_1 = dq
        burst.process_material = dust_mat_dirt
        root.add_child(burst)

        # tire marks pool
        var mm := StandardMaterial3D.new()
        mm.albedo_texture = Assets.t("skid")
        mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mm.cull_mode = BaseMaterial3D.CULL_DISABLED
        mark_mat = mm
        for i in range(MARK_N):
                var mi := MeshInstance3D.new()
                var pm := PlaneMesh.new()
                pm.size = Vector2(0.5, 0.24)
                mi.mesh = pm
                mi.material_override = mm
                mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
                root.add_child(mi)
                mi.visible = false
                marks.append({"n": mi, "age": 0.0})

var dust_r: GPUParticles3D
var dust_f: GPUParticles3D
var mark_mat: StandardMaterial3D

func _dust_process(c: Color) -> ParticleProcessMaterial:
        var p := ParticleProcessMaterial.new()
        p.direction = Vector3(0, 1, 0)
        p.spread = 40.0
        p.initial_velocity_min = 1.0
        p.initial_velocity_max = 2.6
        p.gravity = Vector3(0, -0.7, 0)
        p.scale_min = 0.5
        p.scale_max = 1.7
        var g := Gradient.new()
        g.set_color(0, Color(c.r, c.g, c.b, 0.85))
        g.set_color(1, Color(c.r, c.g, c.b, 0.0))
        var gt := GradientTexture1D.new()
        gt.gradient = g
        p.color_ramp = gt
        return p

func _particle_draw() -> StandardMaterial3D:
        var m := StandardMaterial3D.new()
        m.albedo_texture = Assets.t("dust")
        m.vertex_color_use_as_albedo = true
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
        return m

func update(bike, dt: float) -> void:
        if not enabled:
                if dust_r: dust_r.emitting = false
                if dust_f: dust_f.emitting = false
                return
        var speed: float = bike.linear_velocity.length()
        var dirty: bool = bike.surf_r == "dirt" or bike.surf_f == "dirt"
        var rate := 0.0
        if bike.grounded_r:
                rate = clampf(speed * 0.05 + bike.burnout * 0.8, 0.0, 1.2)
        dust_r.emitting = rate > 0.12
        dust_r.amount_ratio = clampf(rate, 0.1, 1.0)
        dust_f.emitting = bike.grounded_f and speed > 6.0
        if dirty:
                dust_r.process_material = dust_mat_dirt
                dust_f.process_material = dust_mat_dirt
        else:
                dust_r.process_material = dust_mat_ash
                dust_f.process_material = dust_mat_ash
        # tire marks
        var slipping: bool = (bike.burnout > 0.3) or (bike.input["br"] > 0.5 and speed > 5.0) or (bike.input["bf"] > 0.5 and speed > 8.0)
        if slipping and bike.grounded_r and randf() < 0.5:
                _place_mark(bike.contact_r, bike)
        # fade marks
        for mk in marks:
                if mk["n"].visible:
                        mk["age"] += dt
                        var a := clampf(1.0 - mk["age"] / 7.0, 0.0, 1.0) * 0.55
                        (mk["n"].material_override as StandardMaterial3D).albedo_color = Color(1, 1, 1, a)
                        if a <= 0.01:
                                mk["n"].visible = false

func _place_mark(contact: Vector3, bike) -> void:
        var mk: Dictionary = marks[mark_i]
        mark_i = (mark_i + 1) % MARK_N
        var n: MeshInstance3D = mk["n"]
        n.visible = true
        mk["age"] = 0.0
        n.global_position = contact + Vector3(0, 0.03, 0)
        n.rotation = Vector3(-PI / 2, 0, 0)
        n.scale = Vector3(1, randf_range(0.8, 1.4), 1)

func burst_at(pos: Vector3, dirty: bool) -> void:
        if not enabled:
                return
        burst.global_position = pos + Vector3(0, 0.15, 0)
        burst.process_material = dust_mat_dirt if dirty else dust_mat_ash
        burst.restart()
