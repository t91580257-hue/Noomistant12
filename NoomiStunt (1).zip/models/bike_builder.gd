extends RefCounted
## Builds a detailed pitbike visual model. All parts are real 3D meshes
## (tubes, torus wheels, plastics). Returns named nodes used by physics.

const AxR := 0.268          # wheel center rest offset below anchor line
const REAR_X := -0.56
const FRONT_X := 0.60

func build(parent: Node3D, bike_id: String, cst: Dictionary) -> Dictionary:
        var A := Assets
        var refs := {}
        var plastic_mat := A.plastic(BikeData.PLASTIC_COLORS[int(cst.get("plastic", 0))])
        var wheel_style := int(cst.get("wheels", 0))
        var bar_style := int(cst.get("bars", 0))
        var sticker_id := int(cst.get("sticker", 0))
        var rim_mat: StandardMaterial3D = A.mat("dark_metal") if wheel_style == 0 else (A.plastic(Color(0.85, 0.68, 0.15)) if wheel_style == 1 else A.mat("chrome"))
        var fat := wheel_style == 2

        var low_bar := bar_style == 1
        var bar_y := 0.44 if low_bar else 0.48

        # ---------------- frame tubes
        A.tube(parent, Vector3(0.44, 0.34, 0), Vector3(0.40, 0.16, 0), 0.034, A.mat("dark_metal"))       # steering tube
        A.tube(parent, Vector3(0.40, 0.18, 0), Vector3(-0.12, -0.10, 0), 0.034, A.mat("metal"))          # main spar
        A.tube(parent, Vector3(0.40, 0.18, 0), Vector3(0.32, -0.20, 0), 0.028, A.mat("dark_metal"))      # downtube
        A.tube(parent, Vector3(-0.10, 0.02, 0), Vector3(-0.42, 0.14, 0), 0.020, A.mat("dark_metal"))     # seat rail
        A.tube(parent, Vector3(-0.12, -0.10, 0), Vector3(-0.40, 0.10, 0), 0.022, A.mat("dark_metal"))    # subframe strut
        for zs in [-0.09, 0.09]:
                A.tube(parent, Vector3(-0.12, -0.10, zs), Vector3(REAR_X, -AxR + 0.03, zs), 0.022, A.mat("metal"))      # swingarm
                A.tube(parent, Vector3(-0.42, 0.14, zs * 0.6), Vector3(REAR_X, -AxR + 0.05, zs * 0.6), 0.016, A.mat("metal")) # chain stay
                A.tube(parent, Vector3(0.02, -0.06, 0), Vector3(0.02, -0.06, zs * 2.0), 0.014, A.mat("dark_metal"))     # peg mounts

        # ---------------- engine
        A.box(parent, Vector3(0.08, -0.08, 0), Vector3(0.36, 0.24, 0.26), A.mat("engine"))
        A.box(parent, Vector3(0.10, 0.08, 0), Vector3(0.24, 0.10, 0.24), A.mat("engine"))
        A.cyl(parent, Vector3(0.06, -0.10, 0.145), 0.08, 0.035, A.mat("chrome"), PI / 2)
        A.box(parent, Vector3(0.30, 0.12, 0), Vector3(0.05, 0.20, 0.22), A.mat("dark_metal"))            # radiator

        # exhaust
        A.tube(parent, Vector3(0.16, -0.18, 0.06), Vector3(-0.26, -0.22, 0.06), 0.030, A.mat("dark_metal"))
        var muff := A.cyl(parent, Vector3(-0.40, -0.20, 0.06), 0.045, 0.32, A.mat("chrome"))
        muff.rotation = Vector3(0, 0, PI / 2)

        # ---------------- plastics
        var tank := A.capsule(parent, Vector3(0.14, 0.24, 0), 0.10, 0.36, plastic_mat)
        tank.rotation = Vector3(0, 0, PI / 2)
        tank.scale = Vector3(1, 1, 0.72)
        for zs in [-0.15, 0.15]:
                var sh := A.box(parent, Vector3(0.26, 0.18, zs), Vector3(0.30, 0.17, 0.05), plastic_mat)
                sh.rotation = Vector3(0, 0, -0.14)
                var rp := A.box(parent, Vector3(-0.34, 0.10, zs * 0.9), Vector3(0.26, 0.14, 0.04), plastic_mat)
                rp.rotation = Vector3(0, 0, 0.18)
        var rear_fend := A.box(parent, Vector3(-0.46, 0.22, 0), Vector3(0.30, 0.03, 0.22), plastic_mat)
        rear_fend.rotation = Vector3(0, 0, 0.38)
        var plate := A.box(parent, Vector3(0.52, 0.32, 0), Vector3(0.025, 0.26, 0.20), plastic_mat)
        plate.rotation = Vector3(0, 0, 0.12)

        # sticker on right shroud
        if sticker_id > 0:
                var sn: String = ["sticker_star", "sticker_bolt", "sticker_stripes"][sticker_id - 1]
                var st := MeshInstance3D.new()
                var pm := PlaneMesh.new()
                pm.size = Vector2(0.13, 0.10)
                st.mesh = pm
                var sm := StandardMaterial3D.new()
                sm.albedo_texture = A.t(sn)
                sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
                sm.cull_mode = BaseMaterial3D.CULL_DISABLED
                st.material_override = sm
                parent.add_child(st)
                st.position = Vector3(0.28, 0.18, 0.185)
                st.rotation = Vector3(PI / 2, 0, -0.14)

        # ---------------- seat
        var seat := A.box(parent, Vector3(-0.20, 0.17, 0), Vector3(0.44, 0.05, 0.26), A.mat("seat"))
        seat.rotation = Vector3(0, 0, -0.06)

        # ---------------- handlebar
        var bar_mat := A.mat("dark_metal")
        for zs in [-0.07, 0.07]:
                A.tube(parent, Vector3(0.44, 0.30, zs), Vector3(0.50, bar_y, zs), 0.016, bar_mat)
        A.tube(parent, Vector3(0.50, bar_y, -0.31), Vector3(0.50, bar_y, 0.31), 0.018, bar_mat)
        if bar_style == 0:
                A.tube(parent, Vector3(0.50, bar_y + 0.03, -0.12), Vector3(0.50, bar_y + 0.03, 0.12), 0.014, bar_mat)
        for zs in [-0.27, 0.27]:
                A.cyl(parent, Vector3(0.50, bar_y, zs), 0.023, 0.11, A.mat("grip"), PI / 2)
                A.tube(parent, Vector3(0.50, bar_y, zs * 0.8), Vector3(0.57, bar_y - 0.04, zs * 0.8), 0.008, A.mat("chrome"))
        refs["bar_l"] = _marker(parent, Vector3(0.50, bar_y, -0.27))
        refs["bar_r"] = _marker(parent, Vector3(0.50, bar_y, 0.27))
        refs["peg_l"] = _marker(parent, Vector3(0.02, -0.01, -0.16))
        refs["peg_r"] = _marker(parent, Vector3(0.02, -0.01, 0.16))
        refs["seat_m"] = _marker(parent, Vector3(-0.16, 0.21, 0))

        # ---------------- fork
        A.box(parent, Vector3(0.44, 0.26, 0), Vector3(0.07, 0.10, 0.24), A.mat("dark_metal"))            # triple clamp
        for zs in [-0.09, 0.09]:
                A.tube(parent, Vector3(0.43, 0.28, zs), Vector3(0.53, 0.02, zs), 0.018, A.mat("chrome"))     # stanchions

        # ---------------- wheels
        refs["wheel_rear"] = _wheel(parent, Vector3(REAR_X, -AxR, 0), rim_mat, fat)
        refs["wheel_front"] = _wheel(parent, Vector3(FRONT_X, -AxR, 0), rim_mat, fat)
        for zs in [-0.09, 0.09]:
                A.tube(refs["wheel_front"]["holder"], Vector3(0.02, 0.16, zs), Vector3(0, 0.01, zs), 0.024, A.mat("dark_metal"))
        var ffend := A.box(refs["wheel_front"]["holder"], Vector3(0.06, 0.34, 0), Vector3(0.34, 0.03, 0.22), plastic_mat)
        ffend.rotation = Vector3(0, 0, 0.10)

        return refs

func _marker(parent: Node3D, pos: Vector3) -> Node3D:
        var n := Node3D.new()
        parent.add_child(n)
        n.position = pos
        return n

func _wheel(parent: Node3D, axle: Vector3, rim_mat: StandardMaterial3D, fat: bool) -> Dictionary:
        var A := Assets
        var holder := Node3D.new()
        parent.add_child(holder)
        holder.position = axle
        var spin := Node3D.new()
        holder.add_child(spin)
        var zs := 1.35 if fat else 1.0
        A.torus(spin, Vector3.ZERO, 0.32, 0.19, A.mat("rubber"), PI / 2, Vector3(1, 1, zs))
        A.torus(spin, Vector3.ZERO, 0.335, 0.30, A.mat("tire_knob"), PI / 2, Vector3(1, 1, zs))
        A.torus(spin, Vector3.ZERO, 0.20, 0.165, rim_mat, PI / 2, Vector3(1, 1, zs))
        A.cyl(spin, Vector3.ZERO, 0.05, 0.12, A.mat("metal"), PI / 2)
        for i in range(8):
                var ang := TAU * i / 8.0
                var sp := A.box(spin, Vector3(cos(ang) * 0.115, sin(ang) * 0.115, 0), Vector3(0.13, 0.022, 0.03), rim_mat)
                sp.rotation = Vector3(0, 0, ang)
        A.cyl(spin, Vector3(0, 0, 0.075), 0.13, 0.014, A.mat("metal"), PI / 2)
        A.box(spin, Vector3(0.11, 0.04, 0.10), Vector3(0.06, 0.05, 0.04), A.mat("dark_metal"))
        return {"holder": holder, "spin": spin}
