extends Node
## Registers all input actions + keyboard fallbacks (desktop testing).
## Touch buttons (TouchScreenButton) press the same actions -> full multitouch.

const ACTIONS := {
	"gas": [KEY_W, KEY_UP],
	"brake_f": [KEY_SPACE],
	"brake_r": [KEY_S, KEY_DOWN],
	"lean_l": [KEY_A, KEY_LEFT],
	"lean_r": [KEY_D, KEY_RIGHT],
	"wheelie": [KEY_Q],
	"drift": [KEY_E],
	"do_reset": [KEY_R],
	"pause": [KEY_ESCAPE, KEY_P],
	"t_lh": [KEY_1],
	"t_rh": [KEY_2],
	"t_hh": [KEY_3],
	"t_lf": [KEY_Z],
	"t_rf": [KEY_X],
	"t_ff": [KEY_C],
	"t_can": [KEY_4],
	"t_nac": [KEY_5],
	"t_sup": [KEY_6],
	"t_heel": [KEY_7],
	"t_whip": [KEY_F],
	"t_flip": [KEY_G],
	"t_look": [KEY_H],
	"t_ssg": [KEY_8],
	"t_ind": [KEY_9],
	"t_hop": [KEY_0],
	"t_lazy": [KEY_B],
	"t_cof": [KEY_N],
	"t_rock": [KEY_M],
	"t_360": [KEY_V],
}

func _ready() -> void:
	for a in ACTIONS.keys():
		if not InputMap.has_action(a):
			InputMap.add_action(a)
		for k in ACTIONS[a]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(a, ev)
