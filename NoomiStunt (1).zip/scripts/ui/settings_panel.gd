extends RefCounted
## Settings panel builder shared by pause menu and main menu.

const UIB := preload("res://scripts/ui/ui_builder.gd")

static func build(_on_changed: Callable) -> PanelContainer:
        var p: PanelContainer = UIB.panel(Color(0.10, 0.13, 0.19, 0.92), Color(1, 1, 1, 0.4), 20)
        p.custom_minimum_size = Vector2(640, 0)
        var v := VBoxContainer.new()
        v.add_theme_constant_override("separation", 10)
        p.add_child(v)
        v.add_child(UIB.label("НАСТРОЙКИ", 40, Color(1, 1, 1)))

        var music := _slider(v, "Музыка", float(GameState.settings["music_vol"]), func(x: float): GameState.set_setting("music_vol", x))
        var sfx := _slider(v, "Эффекты", float(GameState.settings["sfx_vol"]), func(x: float): GameState.set_setting("sfx_vol", x))
        var eng := _slider(v, "Двигатель", float(GameState.settings["engine_vol"]), func(x: float): GameState.set_setting("engine_vol", x))
        var bsz := _slider(v, "Размер кнопок", float(GameState.settings["btn_scale"]), func(x: float): GameState.set_setting("btn_scale", clampf(x, 0.7, 1.6)), 0.7, 1.6)
        var bal := _slider(v, "Прозрачность кнопок", float(GameState.settings["btn_alpha"]), func(x: float): GameState.set_setting("btn_alpha", clampf(x, 0.3, 1.0)), 0.3, 1.0)
        var sh := _toggle(v, "Тени", bool(GameState.settings["shadows"]), func(b: bool): GameState.set_setting("shadows", b))
        var pt := _toggle(v, "Частицы", bool(GameState.settings["particles"]), func(b: bool): GameState.set_setting("particles", b))
        var vb := _toggle(v, "Вибрация", bool(GameState.settings["vibration"]), func(b: bool): GameState.set_setting("vibration", b))
        return p

static func _slider(parent: Node, text: String, value: float, cb: Callable, mn := 0.0, mx := 1.0) -> HSlider:
        var row := VBoxContainer.new()
        parent.add_child(row)
        var l := UIB.label("%s: %d%%" % [text, int(value * 100.0)], 26)
        row.add_child(l)
        var s := HSlider.new()
        s.min_value = mn
        s.max_value = mx
        s.step = 0.05
        s.value = value
        s.custom_minimum_size = Vector2(560, 40)
        row.add_child(s)
        s.value_changed.connect(func(x: float):
                cb.call(x)
                l.text = "%s: %d%%" % [text, int(x * 100.0)])
        return s

static func _toggle(parent: Node, text: String, value: bool, cb: Callable) -> CheckButton:
        var c := CheckButton.new()
        c.text = text
        c.button_pressed = value
        c.add_theme_font_size_override("font_size", 26)
        parent.add_child(c)
        c.toggled.connect(func(b: bool): cb.call(b))
        return c
