extends Node
## Global game state: profile, progression, records, garage, settings, saving.

const SAVE_PATH := "user://noomistunt_save.cfg"
const VERSION := 1

signal settings_changed

var coins := 0
var xp := 0
var level := 1

# records per map id
var best_time := {}   # map_id -> float seconds
var best_score := {}  # map_id -> int
var unlocked_maps := ["park"]

var owned_bikes := ["noomi125"]
var current_bike := "noomi125"
var current_map := "park"
var custom := {}      # bike_id -> {plastic:int, wheels:int, bars:int, sticker:int, helmet:int, gear:int}

var settings := {
        "music_vol": 0.7,
        "sfx_vol": 0.9,
        "engine_vol": 0.8,
        "btn_scale": 1.0,
        "btn_alpha": 1.0,
        "shadows": true,
        "particles": true,
        "vibration": true,
}

var autotest := false
var shotmode := false
var _loaded := false

const MAP_UNLOCK := {
        "park": {"coins": 0, "level": 1},
        "dirt": {"coins": 400, "level": 4},
        "urban": {"coins": 900, "level": 7},
}

func _ready() -> void:
        process_mode = Node.PROCESS_MODE_ALWAYS
        for a in OS.get_cmdline_user_args():
                if a == "--autotest":
                        autotest = true
                if a == "--shot":
                        shotmode = true
        load_save()
        _apply_level()
        # save roundtrip self-check
        save_game()
        var f := ConfigFile.new()
        if autotest:
                if f.load(SAVE_PATH) == OK and f.has_section("profile"):
                        print("[AUTOTEST] SAVE_OK")
                else:
                        print("[AUTOTEST] SAVE_FAIL")
        if shotmode:
                _shotmode()

func _shotmode() -> void:
        await get_tree().create_timer(2.0).timeout
        await RenderingServer.frame_post_draw
        var img := get_viewport().get_texture().get_image()
        DirAccess.make_dir_recursive_absolute("/tmp/shots")
        var scene := String(get_tree().current_scene.name)
        if img:
                img.save_png("/tmp/shots/scene_" + scene + ".png")
                print("[AUTOTEST] shot saved: scene_", scene)
        get_tree().quit(0)

func level_from_xp(x: int) -> int:
        return int(sqrt(max(0, x) / 300.0)) + 1

func _apply_level() -> void:
        var nl := level_from_xp(xp)
        if nl != level:
                level = nl
        # auto-unlock maps by level
        for m in MAP_UNLOCK.keys():
                if level >= int(MAP_UNLOCK[m]["level"]) and not m in unlocked_maps:
                        unlocked_maps.append(m)
        save_game()

func add_banked(banked_points: int) -> void:
        coins += int(banked_points / 30.0)
        xp += int(banked_points / 10.0)
        _apply_level()

# ------------------------------------------------------------- records
func record_time(map_id: String) -> float:
        return float(best_time.get(map_id, 0.0))

func record_score(map_id: String) -> int:
        return int(best_score.get(map_id, 0))

func submit_time(map_id: String, t: float) -> bool:
        if t > record_time(map_id):
                best_time[map_id] = t
                save_game()
                return true
        return false

func submit_score(map_id: String, s: int) -> bool:
        if s > record_score(map_id):
                best_score[map_id] = s
                save_game()
                return true
        return false

# ------------------------------------------------------------- maps / bikes
func map_unlocked(map_id: String) -> bool:
        return map_id in unlocked_maps

func try_unlock_map(map_id: String) -> bool:
        if map_unlocked(map_id):
                return true
        var req: Dictionary = MAP_UNLOCK[map_id]
        if coins >= int(req["coins"]):
                coins -= int(req["coins"])
                unlocked_maps.append(map_id)
                save_game()
                return true
        return false

func bike_cfg(id: String) -> Dictionary:
        return BikeData.BIKES[id]

func bike_custom(id: String) -> Dictionary:
        if not custom.has(id):
                custom[id] = {"plastic": 0, "wheels": 0, "bars": 0, "sticker": 0, "helmet": 0, "gear": 0}
        return custom[id]

func buy_bike(id: String) -> bool:
        if id in owned_bikes:
                return true
        var price := int(BikeData.BIKES[id]["price"])
        if coins >= price:
                coins -= price
                owned_bikes.append(id)
                current_bike = id
                save_game()
                return true
        return false

func select_bike(id: String) -> void:
        if id in owned_bikes:
                current_bike = id
                save_game()

func set_custom(id: String, key: String, value: int) -> void:
        bike_custom(id)[key] = value
        save_game()

# ------------------------------------------------------------- settings
func set_setting(key: String, value) -> void:
        settings[key] = value
        save_game()
        settings_changed.emit()

# ------------------------------------------------------------- persistence
func save_game() -> void:
        var f := ConfigFile.new()
        f.set_value("profile", "coins", coins)
        f.set_value("profile", "xp", xp)
        f.set_value("profile", "level", level)
        for m in best_time.keys():
                f.set_value("records", "time_" + m, best_time[m])
        for m in best_score.keys():
                f.set_value("records", "score_" + m, best_score[m])
        f.set_value("progress", "unlocked_maps", unlocked_maps)
        f.set_value("garage", "owned_bikes", owned_bikes)
        f.set_value("garage", "current_bike", current_bike)
        for id in custom.keys():
                f.set_value("garage", "custom_" + id, custom[id])
        for k in settings.keys():
                f.set_value("settings", k, settings[k])
        f.save(SAVE_PATH)

func load_save() -> void:
        var f := ConfigFile.new()
        if f.load(SAVE_PATH) != OK:
                return
        _loaded = true
        coins = int(f.get_value("profile", "coins", 0))
        xp = int(f.get_value("profile", "xp", 0))
        level = int(f.get_value("profile", "level", 1))
        for m in ["park", "dirt", "urban"]:
                best_time[m] = float(f.get_value("records", "time_" + m, 0.0))
                best_score[m] = int(f.get_value("records", "score_" + m, 0))
        var um: Array = f.get_value("progress", "unlocked_maps", ["park"])
        unlocked_maps = []
        for m in um:
                unlocked_maps.append(String(m))
        if not "park" in unlocked_maps:
                unlocked_maps.append("park")
        var ob: Array = f.get_value("garage", "owned_bikes", ["noomi125"])
        owned_bikes = []
        for b in ob:
                owned_bikes.append(String(b))
        if owned_bikes.is_empty():
                owned_bikes = ["noomi125"]
        current_bike = String(f.get_value("garage", "current_bike", "noomi125"))
        if not current_bike in owned_bikes:
                current_bike = owned_bikes[0]
        for id in owned_bikes:
                if f.has_section_key("garage", "custom_" + id):
                        var c: Dictionary = f.get_value("garage", "custom_" + id, {})
                        var base := {"plastic": 0, "wheels": 0, "bars": 0, "sticker": 0, "helmet": 0, "gear": 0}
                        for k in base.keys():
                                if c.has(k):
                                        base[k] = int(c[k])
                        custom[id] = base
        for k in settings.keys():
                settings[k] = f.get_value("settings", k, settings[k])
        _apply_level()
