class_name AssetLib
extends Node
## Shared materials, textures and geometry helpers (autoload "Assets").

var tex := {}
var _mats := {}

func t(name: String) -> Texture2D:
        if not tex.has(name):
                tex[name] = load("res://textures/" + name + ".png")
        return tex[name]

# ---------------------------------------------------------------- materials
func _mk(albedo: Color, rough: float, metal: float, em: Color = Color(0, 0, 0)) -> StandardMaterial3D:
        var m := StandardMaterial3D.new()
        m.albedo_color = albedo
        m.roughness = rough
        m.metallic = metal
        if em.a > 0.0:
                m.emission_enabled = true
                m.emission = em
                m.emission_energy_multiplier = 1.0
        return m

func mat(name: String) -> StandardMaterial3D:
        var key := String(name)
        if _mats.has(key):
                return _mats[key]
        var m: StandardMaterial3D
        match key:
                "metal":
                        m = _mk(Color(0.62, 0.64, 0.68), 0.35, 0.9)
                "dark_metal":
                        m = _mk(Color(0.30, 0.31, 0.34), 0.45, 0.8)
                "chrome":
                        m = _mk(Color(0.85, 0.87, 0.9), 0.15, 1.0)
                "engine":
                        m = _mk(Color(0.22, 0.23, 0.26), 0.55, 0.85)
                "rubber":
                        m = _mk(Color(0.07, 0.07, 0.08), 0.95, 0.0)
                "tire_knob":
                        m = _mk(Color(0.05, 0.05, 0.06), 1.0, 0.0)
                "seat":
                        m = _mk(Color(0.08, 0.08, 0.09), 0.85, 0.0)
                "grip":
                        m = _mk(Color(0.12, 0.12, 0.13), 0.8, 0.0)
                "glass":
                        m = _mk(Color(0.15, 0.2, 0.28, 0.55), 0.1, 0.0)
                        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                "visor":
                        m = _mk(Color(0.1, 0.14, 0.2, 0.7), 0.05, 0.2, Color(0.1, 0.3, 0.5) * 0.15)
                        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                "goggle":
                        m = _mk(Color(0.9, 0.9, 0.4, 0.85), 0.15, 0.0, Color(0.4, 0.4, 0.1) * 0.3)
                        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                "boot":
                        m = _mk(Color(0.10, 0.10, 0.11), 0.7, 0.0)
                "glove":
                        m = _mk(Color(0.15, 0.15, 0.17), 0.75, 0.0)
                "dirt":
                        m = _mk(Color(0.42, 0.30, 0.18), 1.0, 0.0)
                "dirt_dark":
                        m = _mk(Color(0.34, 0.24, 0.14), 1.0, 0.0)
                "asphalt":
                        m = _mk(Color(0.30, 0.31, 0.33), 0.75, 0.0)
                "concrete":
                        m = _mk(Color(0.55, 0.55, 0.56), 0.85, 0.0)
                "metal_surf":
                        m = _mk(Color(0.55, 0.57, 0.60), 0.4, 0.7)
                "grass":
                        m = _mk(Color(0.30, 0.52, 0.24), 1.0, 0.0)
                "wood":
                        m = _mk(Color(0.45, 0.32, 0.18), 0.9, 0.0)
                "cone":
                        m = _mk(Color(0.95, 0.45, 0.10), 0.7, 0.0)
                "cone_white":
                        m = _mk(Color(0.9, 0.9, 0.9), 0.7, 0.0)
                "flag_red":
                        m = _mk(Color(0.85, 0.2, 0.2), 0.8, 0.0)
                "flag_blue":
                        m = _mk(Color(0.2, 0.45, 0.85), 0.8, 0.0)
                "flag_yellow":
                        m = _mk(Color(0.95, 0.8, 0.15), 0.8, 0.0)
                "tire_stack":
                        m = _mk(Color(0.10, 0.10, 0.11), 0.95, 0.0)
                "container":
                        m = _mk(Color(0.15, 0.45, 0.60), 0.6, 0.4)
                "container_red":
                        m = _mk(Color(0.65, 0.2, 0.15), 0.6, 0.4)
                "cloud_m":
                        m = _mk(Color(1, 1, 1, 1), 1.0, 0.0)
                        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
                        m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
                        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
                        m.albedo_texture = t("cloud")
                        m.no_depth_test = false
                        m.render_priority = -2
                _:
                        m = _mk(Color(0.8, 0.8, 0.8), 0.8, 0.0)
        _mats[key] = m
        return m

func plastic(c: Color) -> StandardMaterial3D:
        var m := _mk(c, 0.4, 0.1)
        m.clearcoat_enabled = true
        m.clearcoat = 0.6
        return m

func gear(c: Color, shade: float = 1.0) -> StandardMaterial3D:
        return _mk(Color(c.r * shade, c.g * shade, c.b * shade), 0.75, 0.0)

func helmet_m(c: Color) -> StandardMaterial3D:
        var m := _mk(c, 0.25, 0.15)
        m.clearcoat_enabled = true
        m.clearcoat = 0.8
        return m

# ---------------------------------------------------------------- geometry
func tube(parent: Node3D, from: Vector3, to: Vector3, r: float, m: Material) -> MeshInstance3D:
        var dir := to - from
        var len := dir.length()
        if len < 0.0001:
                len = 0.0001
        var mid := (from + to) * 0.5
        var node := MeshInstance3D.new()
        var mesh := CylinderMesh.new()
        mesh.top_radius = r
        mesh.bottom_radius = r
        mesh.height = len
        node.mesh = mesh
        node.material_override = m
        parent.add_child(node)
        node.global_position = mid
        var tgt := mid + dir.normalized()
        if absf(dir.normalized().dot(Vector3.UP)) < 0.999:
                node.look_at(tgt, Vector3.UP)
                node.rotate_object_local(Vector3(1, 0, 0), -PI / 2.0)
        else:
                node.rotation = Vector3(0, 0, 0)
                node.rotate_object_local(Vector3(1, 0, 0), 0 if dir.y > 0 else PI)
        return node

func box(parent: Node3D, pos: Vector3, size: Vector3, m: Material) -> MeshInstance3D:
        var node := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = size
        node.mesh = mesh
        node.material_override = m
        parent.add_child(node)
        node.position = pos
        return node

func cyl(parent: Node3D, pos: Vector3, r: float, h: float, m: Material, axis_x_rot := 0.0) -> MeshInstance3D:
        var node := MeshInstance3D.new()
        var mesh := CylinderMesh.new()
        mesh.top_radius = r
        mesh.bottom_radius = r
        mesh.height = h
        node.mesh = mesh
        node.material_override = m
        parent.add_child(node)
        node.position = pos
        node.rotation = Vector3(axis_x_rot, 0, 0)
        return node

func sphere(parent: Node3D, pos: Vector3, r: float, m: Material, scl := Vector3.ONE) -> MeshInstance3D:
        var node := MeshInstance3D.new()
        var mesh := SphereMesh.new()
        mesh.radius = r
        mesh.height = r * 2.0
        node.mesh = mesh
        node.material_override = m
        node.scale = scl
        parent.add_child(node)
        node.position = pos
        return node

func capsule(parent: Node3D, pos: Vector3, r: float, h: float, m: Material, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
        var node := MeshInstance3D.new()
        var mesh := CapsuleMesh.new()
        mesh.radius = r
        mesh.height = h
        node.mesh = mesh
        node.material_override = m
        node.scale = scl
        parent.add_child(node)
        node.position = pos
        node.rotation = rot
        return node

func torus(parent: Node3D, pos: Vector3, outer: float, inner: float, m: Material, x_rot := 0.0, scl := Vector3.ONE) -> MeshInstance3D:
        var node := MeshInstance3D.new()
        var mesh := TorusMesh.new()
        mesh.outer_radius = outer
        mesh.inner_radius = inner
        node.mesh = mesh
        node.material_override = m
        node.scale = scl
        parent.add_child(node)
        node.position = pos
        node.rotation = Vector3(x_rot, 0, 0)
        return node

# wedge mesh rising toward +X, base at y=0, centered on z
func wedge_mesh(w: float, h: float, d: float) -> ArrayMesh:
        var st := SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        var hw := w / 2.0
        var hd := d / 2.0
        var A := Vector3(-hw, 0, -hd)
        var B := Vector3(hw, 0, -hd)
        var C := Vector3(hw, 0, hd)
        var D := Vector3(-hw, 0, hd)
        var E := Vector3(hw, h, -hd)
        var F := Vector3(hw, h, hd)
        var n_bottom := Vector3(0, -1, 0)
        var n_slope := Vector3(-h, w, 0).normalized()
        var n_back := Vector3(1, 0, 0)
        var n_side1 := Vector3(0, 0, -1)
        var n_side2 := Vector3(0, 0, 1)
        _tri(st, A, B, C, n_bottom)
        _tri(st, A, C, D, n_bottom)
        _tri(st, A, F, E, n_slope)
        _tri(st, A, D, F, n_slope)
        _tri(st, B, C, F, n_back)
        _tri(st, B, F, E, n_back)
        _tri(st, A, B, E, n_side1)
        _tri(st, D, C, F, n_side2)
        return st.commit()

func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, n: Vector3) -> void:
        st.set_normal(n)
        st.add_vertex(a)
        st.set_normal(n)
        st.add_vertex(b)
        st.set_normal(n)
        st.add_vertex(c)

func wedge_points(w: float, h: float, d: float, flip: bool) -> PackedVector3Array:
        var hw := w / 2.0
        var hd := d / 2.0
        var pts := PackedVector3Array([
                Vector3(-hw, 0, -hd), Vector3(hw, 0, -hd), Vector3(hw, 0, hd),
                Vector3(-hw, 0, hd), Vector3(hw, h, -hd), Vector3(hw, h, hd),
        ])
        if flip:
                for i in range(pts.size()):
                        pts[i] = Vector3(-pts[i].x, pts[i].y, pts[i].z)
        return pts

# ---------------------------------------------------------------- static world
func add_static_box(root: Node3D, center: Vector3, size: Vector3, m: Material, surf: String, grip := 1.0) -> StaticBody3D:
        var body := StaticBody3D.new()
        root.add_child(body)
        body.position = center
        var mi := box(body, Vector3.ZERO, size, m)
        mi.name = "Mesh"
        var cs := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        cs.shape = shape
        body.add_child(cs)
        body.set_meta("surf", surf)
        body.set_meta("grip", grip)
        return body

func add_static_wedge(root: Node3D, base_center: Vector3, w: float, h: float, d: float, dir: int, m: Material, surf: String, grip := 1.0) -> StaticBody3D:
        var body := StaticBody3D.new()
        root.add_child(body)
        body.position = base_center
        var flip := dir < 0
        var mi := MeshInstance3D.new()
        mi.mesh = wedge_mesh(w, h, d)
        if flip:
                mi.rotation.y = PI
        mi.material_override = m
        body.add_child(mi)
        var cs := CollisionShape3D.new()
        var shape := ConvexPolygonShape3D.new()
        shape.points = wedge_points(w, h, d, flip)
        cs.shape = shape
        body.add_child(cs)
        body.set_meta("surf", surf)
        body.set_meta("grip", grip)
        return body

func add_deco_mesh(root: Node3D, node: Node3D) -> void:
        root.add_child(node)

func quad(root: Node3D, pos: Vector3, size: Vector2, tex_name: String, unshaded := true, two_sided := true) -> MeshInstance3D:
        var node := MeshInstance3D.new()
        var mesh := PlaneMesh.new()
        mesh.size = size
        node.mesh = mesh
        var m := StandardMaterial3D.new()
        m.albedo_texture = t(tex_name)
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED if unshaded else BaseMaterial3D.SHADING_MODE_PER_PIXEL
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        if two_sided:
                m.cull_mode = BaseMaterial3D.CULL_DISABLED
        node.material_override = m
        root.add_child(node)
        node.position = pos
        return node

func surf_grip(surf: String) -> float:
        match surf:
                "asphalt":
                        return 1.25
                "metal":
                        return 1.05
                "dirt":
                        return 1.0
                _:
                        return 1.0
