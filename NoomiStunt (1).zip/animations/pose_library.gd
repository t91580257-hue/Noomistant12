class_name PoseLib
## Trick pose definitions. Offsets are relative to the rider pelvis in bike
## local space (+X forward, +Y up, +Z toward camera). Targets are points the
## IK limbs reach; "pelvis"/"spine"/"head" tune the body posture.

# target point helpers: [x, y, z]
const POSES := {
        "ride": {
                "pelvis": [0.0, 0.0, 0.0],
                "spine": 0.14, "head": 0.12,
        },
        "stand": {
                "pelvis": [0.0, 0.10, 0.0],
                "spine": 0.02, "head": 0.10,
        },
        "hang_l": {"hand_l": [-0.10, -0.52, -0.15], "spine": 0.18},
        "hang_r": {"hand_r": [-0.10, -0.52, 0.15], "spine": 0.18},
        "hang_both": {
                "hand_l": [-0.04, -0.52, -0.17], "hand_r": [-0.16, -0.52, 0.17],
                "spine": 0.22, "head": 0.05,
        },
        "foot_l_off": {"foot_l": [-0.10, -0.44, -0.16]},
        "foot_r_off": {"foot_r": [-0.10, -0.44, 0.16]},
        "feet_off": {
                "foot_l": [-0.28, -0.22, -0.10], "foot_r": [-0.24, -0.20, 0.10],
                "spine": 0.30,
        },
        "cancan": {
                "foot_r": [0.44, 0.12, 0.16], "spine": 0.24, "head": 0.10,
        },
        "nacnac": {
                "foot_r": [-0.52, -0.02, 0.18], "spine": 0.10, "head": 0.15,
        },
        "superman": {
                "pelvis": [-0.30, -0.14, 0.0],
                "spine": -0.55, "head": -0.25,
                "foot_l": [-0.52, -0.18, -0.08], "foot_r": [-0.52, -0.18, 0.08],
        },
        "heelclicker": {
                "foot_l": [0.42, 0.14, -0.10], "foot_r": [0.42, 0.14, 0.10],
                "spine": 0.30, "head": 0.30,
        },
        "lookback": {"head_yaw": 1.0, "spine": 0.20},
        "ssg": {
                "pelvis": [-0.28, -0.12, 0.0],
                "spine": -0.50, "head": -0.20,
                "foot_l": [-0.50, -0.16, -0.08], "foot_r": [-0.50, -0.16, 0.08],
                "hand_r": [-0.14, 0.22, 0.10],
        },
        "indian": {
                "hand_l": [0.30, 0.05, -0.30], "hand_r": [0.30, 0.05, 0.30],
                "foot_l": [0.36, 0.16, -0.16], "foot_r": [0.36, 0.16, 0.16],
                "spine": 0.15, "head": 0.20,
        },
        "barhop": {
                "foot_l": [0.58, 0.32, -0.10], "foot_r": [0.58, 0.32, 0.10],
                "spine": 0.45, "head": 0.15,
        },
        "lazyboy": {
                "pelvis": [-0.22, -0.10, 0.0],
                "spine": -0.45, "head": -0.10,
                "foot_l": [0.10, -0.34, -0.10], "foot_r": [0.10, -0.34, 0.10],
                "hand_l": [0.42, 0.42, -0.14],
        },
        "coffin": {
                "pelvis": [-0.36, -0.20, 0.0],
                "spine": -0.90, "head": -0.45,
                "hand_l": [0.10, 0.30, -0.28], "hand_r": [0.10, 0.30, 0.28],
                "foot_l": [0.30, 0.02, -0.08], "foot_r": [0.30, 0.02, 0.08],
        },
        "rocksolid": {
                "pelvis": [-0.32, -0.13, 0.0],
                "spine": -0.55, "head": -0.25,
                "foot_l": [-0.58, -0.10, -0.045], "foot_r": [-0.58, -0.10, 0.045],
        },
        "crash": {
                "pelvis": [-0.10, -0.18, 0.0],
                "spine": -0.3, "head": -0.2, "head_yaw": 0.4,
                "hand_l": [0.35, 0.10, -0.30], "hand_r": [-0.25, -0.30, 0.30],
                "foot_l": [0.35, -0.25, -0.20], "foot_r": [-0.30, -0.10, 0.24],
        },
}
