# NoomiStunt — PITBIKE STUNT SIMULATOR (Godot 4.3, Android)

Мобильная 3D-игра про выполнение трюков на питбайке с фиксированной
боковой камерой. Не гонка: главная механика — станты, таймер секунд
станта и комбо-очки.

## Как собрать APK с телефона (без компьютера)

1. Создайте аккаунт на github.com и новый публичный репозиторий.
2. В репозитории: `Add file → Create new file`, введите путь
   `.github/workflows/build-android.yml`, вставьте содержимое файла
   `build-android.yml` (идёт в комплекте), нажмите Commit.
3. `Add file → Upload files` — загрузите `NoomiStunt.zip`, Commit.
4. Откройте вкладку **Actions** → выберите **Build Android APK (NoomiStunt)**
   → **Run workflow** → подождите ~10–15 минут.
5. В завершившемся workflow откройте артефакт **NoomiStunt-Debug-APK**,
   скачайте ZIP, распакуйте — внутри `NoomiStunt-debug.apk`.
6. Разрешите установку из неизвестных источников и установите APK.

Workflow сам распаковывает ZIP, ставит зависимости, качает Godot 4.3,
проходит smoke-тест и собирает DEBUG APK (без релизной подписи).

## Управление (сенсор)

- Слева: ГАЗ, ПЕРЕДНИЙ ТОРМОЗ, ЗАДНИЙ ТОРМОЗ, НАКЛОН ← / →,
  ВИЛЛИ, ДРИФТ, СБРОС, МЕНЮ.
- Справа (вкладки): РУКИ И НОГИ — отпускание конечностей;
  ТРЮКИ — CAN CAN, NAC NAC, SUPERMAN, HEEL CLICKER, WHIP, BACKFLIP, 360;
  ПРО — SUPERMAN SEAT GRAB, INDIAN AIR, BAR HOP, LAZY BOY, COFFIN, ROCK SOLID.
- Клавиатура (для отладки на ПК): W газ, S задний тормоз, Space передний,
  A/D наклон, Q вилли, E дрифт, R сброс, Esc пауза, 1–9/0, Z/X/C — трюки.

## Структура проекта

```
project.godot          — настройки (Mobile renderer, landscape, autoloads)
export_presets.cfg     — Android export preset (debug)
scenes/                — main_menu.tscn, game.tscn, garage.tscn
scripts/core/          — GameState (сохранения), AudioMan (звук), InputSetup
scripts/game/          — физика байка, райдер, камера, карты, трюки, очки
scripts/ui/            — HUD, меню, гараж, пауза, настройки
models/                — билдеры 3D-моделей и библиотека материалов
animations/            — библиотека поз для трюков
resources/             — данные трюков, байков и карт
textures/ audio/       — сгенерированные ассеты
.github/workflows/     — сборка APK
```

## Сохранения

`user://noomistunt_save.cfg` — рекорды времени/очков по картам, монеты,
уровень, купленные байки, кастомизация и настройки.
