extends Node
## Sound system: procedural engine (AudioStreamGenerator), music loop, SFX.

var music_p: AudioStreamPlayer
var skid_p: AudioStreamPlayer
var engine_p: AudioStreamPlayer
var sfx_land: AudioStreamPlayer
var sfx_crash: AudioStreamPlayer
var sfx_click: AudioStreamPlayer
var sfx_coin: AudioStreamPlayer
var sfx_record: AudioStreamPlayer
var sfx_whoosh: AudioStreamPlayer

var gen: AudioStreamGenerator
var playback: AudioStreamGeneratorPlayback
var _phase := 0.0
var _phase2 := 0.0
var rpm := 0.0        # 0..1
var load_a := 0.0     # throttle load 0..1
var _vol_s := 0.0
var skid_level := 0.0  # 0..1 target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	music_p = AudioStreamPlayer.new()
	music_p.stream = _loop_wav("music.wav")
	music_p.volume_db = -8.0
	add_child(music_p)
	music_p.play()

	skid_p = AudioStreamPlayer.new()
	skid_p.stream = _loop_wav("skid.wav")
	skid_p.volume_db = -60.0
	add_child(skid_p)
	skid_p.play()

	engine_p = AudioStreamPlayer.new()
	gen = AudioStreamGenerator.new()
	gen.buffer_length = 0.12
	gen.mix_rate = 22050
	engine_p.stream = gen
	engine_p.volume_db = -60.0
	add_child(engine_p)
	engine_p.play()
	playback = engine_p.get_stream_playback()

	sfx_land = _sfx("land.wav")
	sfx_crash = _sfx("crash.wav")
	sfx_click = _sfx("click.wav")
	sfx_coin = _sfx("coin.wav")
	sfx_record = _sfx("record.wav")
	sfx_whoosh = _sfx("whoosh.wav")
	apply_volumes()
	GameState.settings_changed.connect(apply_volumes)

func _sfx(name: String) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = load("res://audio/" + name)
	add_child(p)
	return p

func _loop_wav(name: String) -> AudioStreamWAV:
	var s: AudioStreamWAV = load("res://audio/" + name)
	if s is AudioStreamWAV:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = s.data.size() / 2  # 16-bit mono
	return s

func apply_volumes() -> void:
	var st: Dictionary = GameState.settings
	music_p.volume_db = linear_to_db(clampf(float(st["music_vol"]), 0.0, 1.0) * 0.5 + 0.001)
	sfx_click.volume_db = linear_to_db(clampf(float(st["sfx_vol"]), 0.0, 1.0) * 0.8)
	sfx_coin.volume_db = linear_to_db(clampf(float(st["sfx_vol"]), 0.0, 1.0) * 0.7)
	sfx_record.volume_db = linear_to_db(clampf(float(st["sfx_vol"]), 0.0, 1.0) * 0.9)
	sfx_land.volume_db = linear_to_db(clampf(float(st["sfx_vol"]), 0.0, 1.0) * 0.9)
	sfx_crash.volume_db = linear_to_db(clampf(float(st["sfx_vol"]), 0.0, 1.0) * 1.0)
	sfx_whoosh.volume_db = linear_to_db(clampf(float(st["sfx_vol"]), 0.0, 1.0) * 0.5)

func set_engine(on: bool) -> void:
	engine_on = on
	if not on:
		rpm = 0.0
		load_a = 0.0

var engine_on := false

func _process(delta: float) -> void:
	# skid loop volume
	var tgt := -60.0 + 42.0 * clampf(skid_level, 0.0, 1.0)
	skid_p.volume_db = lerpf(skid_p.volume_db, tgt, minf(1.0, delta * 10.0))
	# engine synth
	if playback == null or not engine_on:
		return
	var frames := playback.get_frames_available()
	if frames <= 0:
		return
	var base_vol := clampf(float(GameState.settings["engine_vol"]), 0.0, 1.0)
	var target_vol := base_vol * (0.25 + 0.75 * maxf(rpm, load_a * 0.7))
	_vol_s = lerpf(_vol_s, target_vol, 0.15)
	var buf := PackedVector2Array()
	buf.resize(frames)
	var f0 := 42.0 + 230.0 * rpm
	var w0 := TAU * f0 / 22050.0
	var w1 := TAU * f0 * 2.03 / 22050.0
	for i in range(frames):
		_phase += w0
		_phase2 += w1
		if _phase > TAU:
			_phase -= TAU
		if _phase2 > TAU:
			_phase2 -= TAU
		var saw := 2.0 * (_phase / TAU) - 1.0
		var saw2 := 2.0 * (_phase2 / TAU) - 1.0
		var n := randf() * 2.0 - 1.0
		var v := (saw * 0.6 + saw2 * 0.25 + n * (0.12 + 0.25 * load_a)) * _vol_s
		buf[i] = Vector2(v, v)
	playback.push_buffer(buf)

# ------------------------------------------------- public SFX
func click() -> void:
	sfx_click.pitch_scale = randf_range(0.95, 1.08)
	sfx_click.play()

func coin() -> void:
	sfx_coin.play()

func land(hard: float) -> void:
	sfx_land.pitch_scale = clampf(1.15 - hard * 0.05, 0.7, 1.2)
	sfx_land.play()

func crash() -> void:
	sfx_crash.pitch_scale = randf_range(0.9, 1.05)
	sfx_crash.play()

func record() -> void:
	sfx_record.play()

func whoosh() -> void:
	sfx_whoosh.pitch_scale = randf_range(0.85, 1.15)
	sfx_whoosh.play()

func vibrate(ms: int) -> void:
	if bool(GameState.settings["vibration"]):
		Input.vibrate_handheld(ms)
