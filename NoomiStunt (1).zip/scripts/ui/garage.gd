extends Node3D
## Garage: 3D bike/rider showcase on a turntable + full customization UI.

const UIB := preload("res://scripts/ui/ui_builder.gd")
const BikeBuilder := preload("res://models/bike_builder.gd")
const RiderBuilder := preload("res://models/rider_builder.gd")

var turntable: Node3D
var chassis: Node3D
var bike_refs := {}
var rig := {}
var ui: CanvasLayer
var bike_name_lbl: Label
var stats_lbl: Label
var action_btn: Button
var opts_box: VBoxContainer
var cur_tab := 0
var bike_order := ["noomi125", "rocket190", "cobra110"]

func _ready() -> void:
	_build_world()
	_build_ui()
	_rebuild()
	_show_tab(0)

func _build_world() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.14, 0.16, 0.24)
	sm.sky_horizon_color = Color(0.36, 0.40, 0.52)
	sm.ground_bottom_color = Color(0.10, 0.11, 0.14)
	sm.ground_horizon_color = Color(0.20, 0.22, 0.28)
	var sky := Sky.new()
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.light_energy = 1.2
	sun.shadow_enabled = false
	add_child(sun)
	sun.rotation = Vector3(deg_to_rad(-45), deg_to_rad(40), 0)

	var fl := StaticBody3D.new()
	add_child(fl)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(30, 0.4, 30)
	cs.shape = sh
	fl.add_child(cs)
	var flm := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(30, 0.4, 30)
	flm.mesh = bm
	flm.material_override = Assets.plastic(Color(0.11, 0.13, 0.18))
	fl.add_child(flm)
	flm.position = Vector3(0, -0.2, 0)
	var ring := Assets.torus(self, Vector3(0, 0.02, 0), 3.6, 3.4, Assets.plastic(Color(0.15, 0.5, 0.85)))

	turntable = Node3D.new()
	add_child(turntable)
	chassis = Node3D.new()
	chassis.position.y = 0.588
	turntable.add_child(chassis)

	var cam := Camera3D.new()
	add_child(cam)
	cam.position = Vector3(0.3, 1.15, 4.4)
	cam.current = true

func _rebuild() -> void:
	for c in chassis.get_children():
		chassis.remove_child(c)
		c.queue_free()
	var bb := BikeBuilder.new()
	bike_refs = bb.build(chassis, GameState.current_bike, GameState.bike_custom(GameState.current_bike))
	var rb := RiderBuilder.new()
	rig = rb.build(chassis, GameState.bike_custom(GameState.current_bike))
	_pose(rig)
	var cfg: Dictionary = GameState.bike_cfg(GameState.current_bike)
	if bike_name_lbl:
		bike_name_lbl.text = String(cfg["name"])
	if stats_lbl:
		stats_lbl.text = "Разгон %d%%  ·  Скорость %d%%  ·  Вес %d%%  ·  Вилли %d%%" % [
			int(float(cfg["accel_stat"]) * 100), int(float(cfg["speed_stat"]) * 100),
			int(float(cfg["weight_stat"]) * 100), int(float(cfg["wheelie_stat"]) * 100)]
	_update_action_btn()

func _pose(r: Dictionary) -> void:
	var pelvis := turntable.to_global(Vector3(-0.06, 0.888, 0))
	r["pelvis"].global_transform = Transform3D(Basis(), pelvis)
	r["torso"].global_transform = Transform3D(Basis(Vector3(0, 0, 1), 0.2), pelvis + Vector3(0, 0.08, 0))
	r["head"].global_transform = Transform3D(Basis(Vector3(0, 0, 1), 0.5), pelvis + Vector3(0, 0.08, 0) + Vector3(0.2, 0.06, 0))
	var shoulder := pelvis + Vector3(0, 0.08, 0) + Vector3(0.2, 0.06, 0)
	var bl: Vector3 = bike_refs["bar_l"].global_position
	var br: Vector3 = bike_refs["bar_r"].global_position
	_ik(r["ua_l"], r["fa_l"], r["hand_l"], shoulder + Vector3(0, 0, -0.10), bl, 0.26, 0.24)
	_ik(r["ua_r"], r["fa_r"], r["hand_r"], shoulder + Vector3(0, 0, 0.10), br, 0.26, 0.24)
	var pl: Vector3 = bike_refs["peg_l"].global_position
	var pr: Vector3 = bike_refs["peg_r"].global_position
	_ik(r["th_l"], r["sh_l"], r["foot_l"], pelvis + Vector3(0, 0, -0.075), pl, 0.32, 0.32)
	_ik(r["th_r"], r["sh_r"], r["foot_r"], pelvis + Vector3(0, 0, 0.075), pr, 0.32, 0.32)

func _ik(upper: Node3D, lower: Node3D, end_n: Node3D, s: Vector3, t: Vector3, l1: float, l2: float) -> void:
	var s2 := Vector2(s.x, s.y)
	var t2 := Vector2(t.x, t.y)
	var dd := clampf((t2 - s2).length(), absf(l1 - l2) + 0.02, l1 + l2 - 0.02)
	var theta := atan2(t2.y - s2.y, t2.x - s2.x)
	var cs := clampf((l1 * l1 + dd * dd - l2 * l2) / (2.0 * l1 * dd), -1.0, 1.0)
	var a1 := theta + acos(cs)
	var elbow := Vector2(s2.x + cos(a1) * l1, s2.y + sin(a1) * l1)
	var a2 := atan2(t2.y - elbow.y, t2.x - elbow.x)
	var end2 := elbow + Vector2(cos(a2), sin(a2)) * l2
	upper.global_transform = Transform3D(Basis(Vector3(0, 0, 1), a1), Vector3(s2.x, s2.y, s.z))
	lower.global_transform = Transform3D(Basis(Vector3(0, 0, 1), a2), Vector3(elbow.x, elbow.y, s.z))
	end_n.global_transform = Transform3D(Basis(Vector3(0, 0, 1), a2), Vector3(end2.x, end2.y, s.z))

func _process(dt: float) -> void:
	if turntable:
		turntable.rotation.y += dt * 0.22

# ---------------------------------------------------------------- UI
func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)

	var back := UIB.button("← НАЗАД", 30, func(): get_tree().change_scene_to_file("res://scenes/main_menu.tscn"))
	back.position = Vector2(20, 16)
	back.custom_minimum_size = Vector2(180, 60)
	ui.add_child(back)

	var prof := UIB.panel(Color(0.08, 0.11, 0.17, 0.85), Color(1, 1, 1, 0.3), 14)
	prof.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	prof.position = Vector2(1560, 16)
	ui.add_child(prof)
	var pv := VBoxContainer.new()
	prof.add_child(pv)
	pv.add_child(UIB.label("ГАРАЖ", 30, Color(1.0, 0.7, 0.2)))
	pv.add_child(UIB.label("Монеты: %d  ·  Уровень %d" % [GameState.coins, GameState.level], 24, Color(0.9, 0.95, 1.0), 4))

	var bottom := VBoxContainer.new()
	bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_top = -378
	bottom.offset_bottom = -12
	bottom.offset_left = 20
	bottom.offset_right = -20
	ui.add_child(bottom)

	var nav := HBoxContainer.new()
	nav.add_theme_constant_override("separation", 10)
	bottom.add_child(nav)
	var prev := UIB.button("◀", 34, _cycle_bike.bind(-1))
	prev.custom_minimum_size = Vector2(90, 60)
	nav.add_child(prev)
	bike_name_lbl = UIB.label("", 40, Color(1.0, 0.85, 0.3))
	nav.add_child(bike_name_lbl)
	var next := UIB.button("▶", 34, _cycle_bike.bind(1))
	next.custom_minimum_size = Vector2(90, 60)
	nav.add_child(next)
	stats_lbl = UIB.label("", 24, Color(0.85, 0.9, 1.0), 4)
	nav.add_child(stats_lbl)
	action_btn = UIB.button("", 30, _on_action)
	action_btn.custom_minimum_size = Vector2(260, 60)
	nav.add_child(action_btn)

	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	bottom.add_child(tabs)
	var tab_names := ["ЦВЕТ", "КОЛЁСА", "РУЛЬ", "НАКЛЕЙКИ", "ШЛЕМ", "ЭКИПИРОВКА"]
	for i in range(tab_names.size()):
		var tb := UIB.button(tab_names[i], 24, _show_tab.bind(i))
		tb.custom_minimum_size = Vector2(200, 52)
		tabs.add_child(tb)

	var opt_panel := UIB.panel(Color(0.08, 0.11, 0.17, 0.85), Color(1, 1, 1, 0.28), 14)
	bottom.add_child(opt_panel)
	opts_box = VBoxContainer.new()
	opts_box.add_theme_constant_override("separation", 8)
	opt_panel.add_child(opts_box)

func _cycle_bike(dir: int) -> void:
	AudioMan.click()
	var i := bike_order.find(GameState.current_bike)
	i = (i + dir + bike_order.size()) % bike_order.size()
	GameState.current_bike = bike_order[i]
	GameState.save_game()
	_rebuild()
	_show_tab(cur_tab)

func _show_tab(i: int) -> void:
	cur_tab = i
	for c in opts_box.get_children():
		c.queue_free()
	var cst := GameState.bike_custom(GameState.current_bike)
	match i:
		0:
			_swatch_row(BikeData.PLASTIC_COLORS, int(cst["plastic"]), func(idx: int): GameState.set_custom(GameState.current_bike, "plastic", idx))
		1:
			_named_row(BikeData.WHEEL_STYLES, int(cst["wheels"]), func(idx: int): GameState.set_custom(GameState.current_bike, "wheels", idx))
		2:
			_named_row(BikeData.BAR_STYLES, int(cst["bars"]), func(idx: int): GameState.set_custom(GameState.current_bike, "bars", idx))
		3:
			_named_row(BikeData.STICKERS, int(cst["sticker"]), func(idx: int): GameState.set_custom(GameState.current_bike, "sticker", idx))
		4:
			_swatch_row(BikeData.HELMET_COLORS, int(cst["helmet"]), func(idx: int): GameState.set_custom(GameState.current_bike, "helmet", idx))
		5:
			_swatch_row(BikeData.GEAR_COLORS, int(cst["gear"]), func(idx: int): GameState.set_custom(GameState.current_bike, "gear", idx))

func _swatch_row(colors: Array, cur: int, cb: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	opts_box.add_child(row)
	for i in range(colors.size()):
		var c: Color = colors[i]
		var b := Button.new()
		b.custom_minimum_size = Vector2(72, 56)
		var sb := StyleBoxFlat.new()
		sb.bg_color = c
		sb.set_corner_radius_all(10)
		sb.set_border_width_all(4 if i == cur else 1)
		sb.border_color = Color(1, 1, 1, 0.95) if i == cur else Color(1, 1, 1, 0.35)
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
		row.add_child(b)
		var idx := i
		b.pressed.connect(func():
			AudioMan.click()
			cb.call(idx)
			_rebuild()
			_show_tab(cur_tab))

func _named_row(names: Array, cur: int, cb: Callable) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	opts_box.add_child(row)
	for i in range(names.size()):
		var b := UIB.button(String(names[i]), 24, func():
			AudioMan.click()
			cb.call(i)
			_rebuild()
			_show_tab(cur_tab))
		b.custom_minimum_size = Vector2(220, 56)
		b.modulate = Color(1.2, 1.2, 1.2) if i == cur else Color(0.8, 0.8, 0.8, 0.85)
		row.add_child(b)

func _update_action_btn() -> void:
	if not bike_name_lbl:
		return
	if GameState.current_bike in GameState.owned_bikes:
		action_btn.text = "ВЫБРАН"
		action_btn.disabled = true
	else:
		var price := int(GameState.bike_cfg(GameState.current_bike)["price"])
		action_btn.text = "КУПИТЬ ЗА %d" % price
		action_btn.disabled = GameState.coins < price

func _on_action() -> void:
	AudioMan.click()
	if GameState.buy_bike(GameState.current_bike):
		AudioMan.coin()
		_rebuild()
		_show_tab(cur_tab)
