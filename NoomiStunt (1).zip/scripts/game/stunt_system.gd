extends RefCounted
## Stunt chain system: decides what counts as a stunt, runs the stunt-seconds
## timer, handles chain continuation/grace, crash resets and records.

signal chain_ended(time: float, banked: bool)
signal record_live(time: float)
signal trick_started(id: String, name: String)
signal crash_requested(reason: String)

var bike          # bike.gd
var rider         # rider.gd

var chain_time := 0.0
var chain_active := false
var _grace := 0.0
var _hold := {}            # action -> seconds held
var active_tricks := []    # ids of valid, held tricks this frame
var _pose_trick := ""      # trick driving the pose
var _hands_off := [false, false]
var _feet_off := [false, false]
var _ground_no_hands := 0.0
var _ground_no_feet := 0.0
var _best := 0.0
var _map_id := "park"
var _record_flashed := false
var _last_scored := {}     # action -> bool (scored once per hold)
var _rel_t := {}           # action -> time of last release
var ended := false

func setup(b, r, map_id: String, best: float) -> void:
        bike = b
        rider = r
        _map_id = map_id
        _best = best

func reset() -> void:
        chain_time = 0.0
        chain_active = false
        _grace = 0.0
        _hold.clear()
        active_tricks.clear()
        _pose_trick = ""
        _hands_off = [false, false]
        _feet_off = [false, false]
        _ground_no_hands = 0.0
        _ground_no_feet = 0.0
        _record_flashed = false
        _last_scored.clear()
        ended = false

func update(dt: float, score) -> void:
        if ended:
                return
        # ---------- poll trick buttons
        var air: bool = bike.air
        active_tricks.clear()
        var best_score := -1
        _pose_trick = ""
        var hands := [false, false]
        var feet := [false, false]
        for id in TrickData.TRICKS.keys():
                var t: Dictionary = TrickData.TRICKS[id]
                var held := Input.is_action_pressed(id)
                if held:
                        _hold[id] = float(_hold.get(id, 0.0)) + dt
                else:
                        if float(_hold.get(id, 0.0)) > 0.0:
                                _rel_t[id] = Time.get_ticks_msec() / 1000.0
                        _hold[id] = 0.0
                        _last_scored[id] = false
                        continue
                var ok_ctx: bool = (not t["air"]) or air
                var long_enough := float(_hold[id]) >= float(t["hold"])
                if ok_ctx and long_enough:
                        active_tricks.append(id)
                        if int(t["score"]) > best_score:
                                best_score = int(t["score"])
                                _pose_trick = id
                        var limb: String = t["limb"]
                        if limb.find("hl") >= 0 or limb.find("hh") >= 0:
                                hands[0] = true
                        if limb.find("hr") >= 0 or limb.find("hh") >= 0:
                                hands[1] = true
                        if limb.find("fl") >= 0 or limb.find("ff") >= 0:
                                feet[0] = true
                        if limb.find("fr") >= 0 or limb.find("ff") >= 0:
                                feet[1] = true
                        if not bool(_last_scored.get(id, false)):
                                _last_scored[id] = true
                                score.award(id)
                                trick_started.emit(id, String(t["name"]))
        # 360 spin trigger
        if Input.is_action_just_pressed("t_360") and air:
                bike.start_360()
        _hands_off = hands
        _feet_off = feet

        # ---------- pose for rider
        var pose_id := ""
        if _pose_trick != "":
                pose_id = String(TrickData.TRICKS[_pose_trick]["pose"])
        else:
                var stand: bool = bike.wheelie_active or (bike.grounded_r and not bike.grounded_f)
                pose_id = "stand" if stand else "ride"
        rider.apply_state({"pose": pose_id})

        # ---------- stunt chain
        var wheelie_stunt: bool = bike.wheelie_active and bike.wheelie_time > 0.25
        var stoppie_stunt: bool = bike.stoppie_active and bike.stoppie_time > 0.25
        var any_trick := active_tricks.size() > 0
        var stunt_now := wheelie_stunt or stoppie_stunt or any_trick

        if stunt_now:
                chain_active = true
                _grace = 0.0
                chain_time += dt
                if _best > 0.0 and chain_time > _best and not _record_flashed:
                        _record_flashed = true
                        record_live.emit(chain_time)
        else:
                if chain_active:
                        _grace += dt
                        if _grace > 1.2:
                                _end_chain(true)

        # ---------- ground limb rules
        if not air:
                if hands[0] and hands[1]:
                        _ground_no_hands += dt
                        if _ground_no_hands > 0.6:
                                crash_requested.emit("ОТПУСТИЛ РУЛЬ НА ЗЕМЛЕ")
                                return
                else:
                        _ground_no_hands = 0.0
                if feet[0] and feet[1]:
                        _ground_no_feet += dt
                        if _ground_no_feet > 0.55:
                                crash_requested.emit("СНЕС С НОГ НА ЗЕМЛЕ")
                                return
                else:
                        _ground_no_feet = 0.0
        else:
                _ground_no_hands = 0.0
                _ground_no_feet = 0.0

func on_landing(impact: float) -> bool:
        ## Returns true if landing is fatal.
        var reason := ""
        for id in TrickData.AIR_LIMB:
                if Input.is_action_pressed(id):
                        reason = "ТРЮК НЕ ЗАВЕРШЁН"
                        break
        if reason == "" and not bike.yaw_ok_for_landing():
                reason = "КРУТИЛКА НЕ ЗАВЕРШЕНА"
        if reason == "" and impact > 10.5:
                reason = "ЖЁСТКОЕ ПРИЗЕМЛЕНИЕ"
        if reason == "" and impact > 3.5 and absf(bike.flip_accum) > 1.2:
                # bad alignment after real rotation (failed flip)
                var slope_pitch := atan2(-bike.norm_r.x, bike.norm_r.y)
                var err := absf(wrapf(bike.pitch - slope_pitch, -PI, PI))
                if err > 1.05:
                        reason = "НЕУДАЧНОЕ ПРИЗЕМЛЕНИЕ"
        if reason != "":
                crash_requested.emit(reason)
                return true
        return false

func hard_landing(impact: float) -> void:
        if impact > 6.0:
                pass  # handled by HUD toast in game

func on_crash() -> void:
        _end_chain(false)

func _end_chain(banked: bool) -> void:
        if ended:
                return
        ended = true
        var t := chain_time
        chain_active = false
        chain_ended.emit(t, banked)

func force_end() -> void:
        _end_chain(true)

func hands_state() -> Array:
        return _hands_off

func feet_state() -> Array:
        return _feet_off

func recent_air_trick() -> bool:
        for id in TrickData.AIR_ONLY:
                if float(_hold.get(id, 0.0)) > 0.0 and float(_hold[id]) < 0.5:
                        return true
        return false
