extends Camera3D
## Fixed side-view camera: no rotation, smooth horizontal follow,
## rises on high jumps, auto-zooms out with speed and height.

var target: Node3D
var shake := 0.0

var _sx := 0.0
var _sy := 2.0
var _sd := 8.0

func _ready() -> void:
	fov = 55.0
	near = 0.2
	far = 300.0

func set_target(t: Node3D) -> void:
	target = t
	if t:
		_sx = t.global_position.x
		_sy = t.global_position.y + 1.6

func _process(dt: float) -> void:
	if target == null or not is_instance_valid(target):
		return
	var bp := target.global_position
	var vel := Vector3.ZERO
	if target is RigidBody3D:
		vel = (target as RigidBody3D).linear_velocity
	var ahead := clampf(vel.x * 0.35, -3.0, 3.0)
	var speed := vel.length()
	var air_h := maxf(0.0, bp.y - 1.0)
	var want_x := bp.x + ahead
	var want_y := maxf(bp.y + 1.5, 1.9)
	var want_d := 8.2 + speed * 0.14 + clampf(air_h * 0.55, 0.0, 3.6)
	want_d = minf(want_d, 14.5)
	var kx := 1.0 - exp(-6.0 * dt)
	var ky := 1.0 - exp(-3.5 * dt)
	var kd := 1.0 - exp(-2.5 * dt)
	_sx = lerpf(_sx, want_x, kx)
	_sy = lerpf(_sy, want_y, ky)
	_sd = lerpf(_sd, want_d, kd)
	var off := Vector3(0, 0, 0)
	if shake > 0.0:
		shake = maxf(0.0, shake - dt * 2.2)
		off = Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * shake * 0.25
	position = Vector3(_sx, _sy, _sd) + off
	rotation = Vector3.ZERO   # strictly side view

func kick(amount: float) -> void:
	shake = minf(1.2, shake + amount)
