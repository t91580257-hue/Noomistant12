extends Node3D
## Game orchestrator: builds the world, bike, rider, camera, HUD, effects;
## wires stunt/score systems; handles crashes, respawns, pause; runs the
## built-in physics autotest when launched with `-- --autotest`.

const BikeScript := preload("res://scripts/game/bike.gd")
const RiderScript := preload("res://scripts/game/rider.gd")
const CamScript := preload("res://scripts/game/camera_rig.gd")
const MapBuilder := preload("res://scripts/game/map_builder.gd")
const BikeBuilder := preload("res://models/bike_builder.gd")
const RiderBuilder := preload("res://models/rider_builder.gd")
const StuntSys := preload("res://scripts/game/stunt_system.gd")
const ScoreSys := preload("res://scripts/game/score_system.gd")
const EffectsSys := preload("res://scripts/game/effects.gd")
const HudScene := preload("res://scripts/ui/hud.gd")
const PauseScene := preload("res://scripts/ui/pause_menu.gd")

var map_id := "park"
var map_root: Node3D
var map_info := {}
var clouds := []

var bike: RigidBody3D
var all_yaw: Node3D
var bike_yaw: Node3D
var rider: Node3D
var cam: Camera3D
var hud: CanvasLayer
var pause_menu: CanvasLayer
var effects
var stunt
var score

var dead := false
var respawn_t := Transform3D(Basis(), Vector3(2.0, 1.0, 0))
var _last_safe_ms := 0
var _last_clean := true
var _flip_awarded := false
var _360_awarded := false

# autotest telemetry
var AT := {"fails": 0, "speed": 0.0, "speed_max": 0.0, "pitch": 0.0, "air": 0.0, "landings": 0, "chain": 0.0, "crashes": 0, "flip": 0.0, "respawns": 0, "pending_max": 0}

func _ready() -> void:
        process_mode = Node.PROCESS_MODE_PAUSABLE
        add_to_group("game")
        map_id = GameState.current_map if GameState.map_unlocked(GameState.current_map) else "park"

        var mb := MapBuilder.new()
        map_info = mb.build(self, map_id, {"shadows": bool(GameState.settings["shadows"])})
        respawn_t = map_info["spawn"]
        _collect_clouds()

        # ---------------- bike + rider
        bike = RigidBody3D.new()
        bike.name = "Bike"
        bike.set_script(BikeScript)
        add_child(bike)
        bike.global_position = (map_info["spawn"] as Transform3D).origin

        all_yaw = Node3D.new()
        all_yaw.name = "AllYaw"
        bike.add_child(all_yaw)
        bike_yaw = Node3D.new()
        bike_yaw.name = "BikeYaw"
        all_yaw.add_child(bike_yaw)

        var bb := BikeBuilder.new()
        var brefs: Dictionary = bb.build(bike_yaw, GameState.current_bike, GameState.bike_custom(GameState.current_bike))

        var rb := RiderBuilder.new()
        rider = Node3D.new()
        rider.name = "Rider"
        rider.set_script(RiderScript)
        all_yaw.add_child(rider)
        var rrig: Dictionary = rb.build(rider, GameState.bike_custom(GameState.current_bike))

        var stats: Dictionary = GameState.bike_cfg(GameState.current_bike)
        bike.setup(stats, bike_yaw, brefs)
        rider.setup(bike, all_yaw, rrig, brefs)

        # ---------------- camera
        cam = Camera3D.new()
        cam.set_script(CamScript)
        add_child(cam)
        cam.set_target(bike)
        cam.current = true

        # ---------------- effects
        effects = EffectsSys.new()
        effects.setup(self, bike)
        effects.enabled = bool(GameState.settings["particles"])

        # ---------------- systems
        stunt = StuntSys.new()
        score = ScoreSys.new()
        stunt.setup(bike, rider, map_id, GameState.record_time(map_id))
        score.setup(map_id, GameState.record_score(map_id))
        stunt.crash_requested.connect(_on_crash_requested)
        stunt.chain_ended.connect(_on_chain_ended)
        stunt.record_live.connect(func(_t: float): hud.flash_record_live())
        bike.landed.connect(_on_landed)
        bike.flip_done.connect(_on_flip_done)
        score.popup.connect(func(txt: String, col: Color): hud.toast(txt, col))
        score.score_changed.connect(func(a: int, b: int, c: int): hud.update_score(a, b, c))

        # ---------------- UI
        hud = CanvasLayer.new()
        hud.set_script(HudScene)
        add_child(hud)
        hud.pause_pressed.connect(_open_pause)
        hud.set_map_info(String(MapData.MAPS[map_id]["name"]), GameState.record_time(map_id))
        hud.update_score(0, 1, 0)

        pause_menu = CanvasLayer.new()
        pause_menu.set_script(PauseScene)
        add_child(pause_menu)
        pause_menu.restart_requested.connect(_restart)
        pause_menu.menu_requested.connect(_to_menu)

        GameState.settings_changed.connect(_apply_quality)

        if GameState.autotest:
                _autotest.call_deferred()

func _collect_clouds() -> void:
        for n in _walk(self):
                if n is Node3D and (n as Node3D).has_meta("drift"):
                        clouds.append(n)

func _walk(n: Node) -> Array:
        var out := [n]
        for c in n.get_children():
                out += _walk(c)
        return out

func _apply_quality() -> void:
        var sun: DirectionalLight3D = map_info["sun"]
        sun.shadow_enabled = bool(GameState.settings["shadows"])
        effects.enabled = bool(GameState.settings["particles"])

# ---------------------------------------------------------------- loop
func _physics_process(dt: float) -> void:
        if Input.is_action_just_pressed("pause"):
                _open_pause()
                return
        if Input.is_action_just_pressed("do_reset") and not dead:
                if stunt.chain_active:
                        stunt.force_end()
                # manual reset returns to the start of the map
                var sp: Transform3D = map_info["spawn"]
                bike.teleport_to(Transform3D(Basis(), sp.origin + Vector3(0, 0.8, 0)))
                return
        if dead:
                return
        stunt.update(dt, score)
        rider.update(dt, {})
        bike.visual_update(dt)
        effects.update(bike, dt)
        hud.update_timer(stunt.chain_time, stunt.chain_active)
        hud.highlight_buttons()
        hud.update_speed(bike.linear_velocity.length() * 3.6)
        if GameState.autotest:
                _track(dt)

func _process(dt: float) -> void:
        for c in clouds:
                var d: float = c.get_meta("drift")
                c.position.x += d * dt
                if c.position.x > map_info["data"]["len"] + 20.0:
                        c.position.x = -20.0

# ---------------------------------------------------------------- events
func _on_landed(impact: float) -> void:
        if dead or impact < 1.0:
                return
        AT["landings"] += 1
        var fatal: bool = stunt.on_landing(impact)
        if fatal:
                return
        if impact > 6.0:
                hud.toast("ЖЁСТКОЕ ПРИЗЕМЛЕНИЕ", Color(1.0, 0.7, 0.4))
                cam.kick(0.4)
        _last_clean = impact < 4.5
        if bike.max_air_h > 0.6 and bike.air_time > 0.25:
                score.add_air_bonus(bike.air_time, bike.max_air_h)
                if bike.air_time > 0.8:
                        AudioMan.whoosh()
        if not _360_awarded and bike.spin_done_flag:
                _360_awarded = true
                bike.spin_done_flag = false
                score.award("t_360")
                hud.toast("360 ВЫПОЛНЕН!", Color(0.6, 0.9, 1.0))

func _on_flip_done(deg: float) -> void:
        if dead:
                return
        if deg >= 300.0 and not _flip_awarded:
                _flip_awarded = true
                score.award("t_flip")
                hud.toast("BACKFLIP %d°!" % int(deg), Color(1.0, 0.8, 0.25))
        elif deg >= 300.0:
                score.award("t_flip")

func _on_chain_ended(time: float, banked: bool) -> void:
        if banked and time > 0.4:
                var gained: int = score.bank(_last_clean)
                var best_before := GameState.record_time(map_id)
                var is_rec := GameState.submit_time(map_id, time)
                hud.toast("СЕРИЯ %s сек  +%d очков" % [hud._fmt(time), gained], Color(0.65, 1.0, 0.7))
                if is_rec and best_before > 0.0:
                        hud.show_record(time)
                elif is_rec:
                        hud.toast("ЛУЧШЕЕ ВРЕМЯ!", Color(1.0, 0.85, 0.3))
                AudioMan.coin()
        stunt.reset()
        _last_clean = true
        _flip_awarded = false
        _360_awarded = false

func _on_crash_requested(reason: String) -> void:
        if dead:
                return
        if GameState.autotest:
                print("[AUTOTEST] CRASH reason=", reason)
        dead = true
        AT["crashes"] += 1
        stunt.on_crash()
        var lost: int = score.lose()
        bike.controls_enabled = false
        bike.crash_latch()
        rider.crash_pose()
        effects.burst_at(bike.global_position, bike.surf_r == "dirt")
        AudioMan.crash()
        AudioMan.vibrate(90)
        cam.kick(1.0)
        hud.show_crash(reason, lost)
        respawn_t.origin.y = maxf(respawn_t.origin.y, 1.0)
        var timer := get_tree().create_timer(1.7)
        timer.timeout.connect(_respawn)

func _respawn() -> void:
        if not dead:
                return
        hud.hide_crash()
        AT["respawns"] += 1
        _do_respawn_now()

func _do_respawn_now() -> void:
        var t := respawn_t
        bike.teleport_to(Transform3D(Basis(), t.origin + Vector3(0, 0.8, 0)))
        bike.controls_enabled = true
        dead = false
        stunt.reset()
        _last_clean = true
        _flip_awarded = false
        _360_awarded = false

func store_safe(t: Transform3D) -> void:
        var now := Time.get_ticks_msec()
        if now - _last_safe_ms < 700:
                return
        if dead:
                return
        _last_safe_ms = now
        respawn_t = Transform3D(Basis(), t.origin + Vector3(0, 0.9, 0))

# ---------------------------------------------------------------- nav
func _open_pause() -> void:
        pause_menu.open()

func _restart() -> void:
        get_tree().reload_current_scene()

func _to_menu() -> void:
        get_tree().paused = false
        get_tree().change_scene_to_file("res://scenes/main_menu.tscn")

# ---------------------------------------------------------------- autotest
func _track(_dt: float) -> void:
        var v := bike.linear_velocity.length()
        if v > AT["speed_max"]:
                AT["speed_max"] = v
        var p := absf(bike.pitch)
        if p > AT["pitch"]:
                AT["pitch"] = p
        if bike.air and bike.air_time > AT["air"]:
                AT["air"] = bike.air_time
        if stunt.chain_time > AT["chain"]:
                AT["chain"] = stunt.chain_time
        var f := maxf(absf(bike.flip_accum), bike.flip_last)
        if f > AT["flip"]:
                AT["flip"] = f
        if score.pending > AT["pending_max"]:
                AT["pending_max"] = score.pending

func _wt(sec: float) -> void:
        await get_tree().create_timer(sec).timeout

func _shot(name: String) -> void:
        if DisplayServer.get_name() == "headless":
                return
        await RenderingServer.frame_post_draw
        var img := get_viewport().get_texture().get_image()
        if img:
                img.save_png("/tmp/shots/" + name + ".png")
                print("[AUTOTEST] shot saved: ", name)

func _chk(cond: bool, name: String) -> void:
        if cond:
                print("[AUTOTEST] OK ", name)
        else:
                print("[AUTOTEST] FAIL ", name)
                AT["fails"] += 1

func _autotest() -> void:
    print("[AUTOTEST] game scene loaded, map=", map_id)
    DirAccess.make_dir_recursive_absolute("/tmp/shots")
    await _wt(0.6)
    await _shot("01_start")
    Input.action_press("gas")
    # 1) accelerate to speed
    var ok := await _until(func(): return bike.linear_velocity.length() > 12.0, 6.0)
    _chk(ok, "MOVEMENT")
    # 2) wheelie at speed on flat ground (before the first kicker)
    ok = await _until(func(): return bike.grounded_r and bike.grounded_f and bike.linear_velocity.length() > 7.0, 6.0)
    Input.action_press("wheelie")
    await _wt(0.45)
    await _shot("02_wheelie")
    await _wt(0.35)
    Input.action_release("wheelie")
    _chk(AT["pitch"] > 0.12, "WHEELIE_LIFT")
    # 3) keep gas, wait for a jump over the kicker and a landing
    Input.action_press("t_lh")
    await _wt(0.55)
    await _shot("03_air_trick")
    Input.action_release("t_lh")
    ok = await _until(func(): return AT["landings"] >= 1, 8.0)
    _chk(ok, "AIR_JUMP")
    # 4) brake down
    var v_before := bike.linear_velocity.length()
    Input.action_press("brake_r")
    ok = await _until(func(): return bike.linear_velocity.length() < v_before - 3.0, 4.0)
    Input.action_release("brake_r")
    _chk(ok and AT["speed_max"] > 12.0, "BRAKE")
    # 5) ensure grounded and slow, then both hands off -> crash
    ok = await _until(func(): return (not bike.air) and bike.linear_velocity.length() < 5.0, 8.0)
    Input.action_press("brake_r")
    ok = await _until(func(): return bike.linear_velocity.length() < 4.0, 6.0)
    Input.action_release("brake_r")
    Input.action_press("t_hh")
    ok = await _until(func(): return AT["crashes"] >= 1, 4.0)
    await _shot("05_crash")
    Input.action_release("t_hh")
    _chk(ok, "CRASH_NO_HANDS_ON_GROUND")
    ok = await _until(func(): return (not dead) and bike.controls_enabled, 4.0)
    _chk(ok, "RESPAWN")
    # 5b) one-hander scores points
    ok = await _until(func(): return (not bike.air) and bike.linear_velocity.length() < 6.0, 6.0)
    Input.action_press("t_lh")
    ok = await _until(func(): return score.pending > 0, 3.0)
    await _shot("07_one_hander")
    Input.action_release("t_lh")
    _chk(ok, "TRICK_POINTS")
    _chk(AT["chain"] > 0.2, "STUNT_CHAIN_TIMER")
    # 6) gas + backflips whenever airborne
    Input.action_press("gas")
    var t0 := Time.get_ticks_msec()
    var flip_held := false
    while Time.get_ticks_msec() - t0 < 20000:
        if bike.global_position.x > 112.0 and not bike.air:
            # reached map end: reset back to spawn and keep flipping
            Input.action_press("do_reset")
            await _wt(0.3)
            Input.action_release("do_reset")
            await _wt(0.6)
        if bike.air:
            if not flip_held:
                Input.action_press("t_flip")
                flip_held = true
                await _wt(0.4)
                await _shot("06_backflip")
            if AT["flip"] > 2.5:
                break
        else:
            if flip_held:
                Input.action_release("t_flip")
                flip_held = false
        await _wt(0.05)
    if flip_held:
        Input.action_release("t_flip")
    _chk(AT["flip"] > 2.5, "BACKFLIP_ROTATION")
    _chk(AT["landings"] >= 2, "MULTIPLE_JUMPS")
    Input.action_release("gas")
    # 7) air-only rules on the ground
    Input.action_press("brake_r")
    var air_streak := 0.0
    var settle_t0 := Time.get_ticks_msec()
    ok = false
    while Time.get_ticks_msec() - settle_t0 < 16000:
        if (not bike.air) and bike.linear_velocity.length() < 5.0:
            ok = true
            break
        if bike.air:
            air_streak += 0.05
            if air_streak > 2.5:
                Input.action_press("do_reset")
                await _wt(0.25)
                Input.action_release("do_reset")
                air_streak = 0.0
        else:
            air_streak = 0.0
        await _wt(0.05)
    Input.action_release("brake_r")
    if ok:
        Input.action_press("t_sup")
        await _wt(0.4)
        _chk(not stunt.active_tricks.has("t_sup"), "AIR_ONLY_SUPERMAN_BLOCKED")
        Input.action_release("t_sup")
        Input.action_press("t_can")
        await _wt(0.4)
        _chk(not stunt.active_tricks.has("t_can"), "AIR_ONLY_CANCAN_BLOCKED")
        Input.action_release("t_can")
    else:
        print("[AUTOTEST] SKIP AIR_ONLY checks (never settled)")
    print("[AUTOTEST] SUMMARY fails=", AT["fails"], " speed_max=", AT["speed_max"], " pitch_max=", AT["pitch"], " air_max=", AT["air"], " landings=", AT["landings"], " chain_max=", AT["chain"], " crashes=", AT["crashes"], " flip_max=", AT["flip"], " pts_max=", AT["pending_max"])
    get_tree().quit(1 if AT["fails"] > 0 else 0)

func _until(pred: Callable, timeout: float) -> bool:
    var t0 := Time.get_ticks_msec()
    while Time.get_ticks_msec() - t0 < int(timeout * 1000.0):
        if pred.call():
            return true
        await _wt(0.05)
    return false
