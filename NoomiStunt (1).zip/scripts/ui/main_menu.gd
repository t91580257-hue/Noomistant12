extends Control
## Main menu: 3D bike showcase background + full navigation UI.

const UIB := preload("res://scripts/ui/ui_builder.gd")
const SettingsPanel := preload("res://scripts/ui/settings_panel.gd")
const BikeBuilder := preload("res://models/bike_builder.gd")
const RiderBuilder := preload("res://models/rider_builder.gd")

var showcase: Node3D
var turntable: Node3D
var cam: Camera3D
var ui: CanvasLayer
var popups := {}
var profile_lbl: Label
var xp_bar: ProgressBar

func _ready() -> void:
        _build_showcase()
        _build_ui()
        _open_popup("")

func _build_showcase() -> void:
        showcase = Node3D.new()
        add_child(showcase)

        var env := Environment.new()
        env.background_mode = Environment.BG_SKY
        var sm := ProceduralSkyMaterial.new()
        sm.sky_top_color = Color(0.10, 0.13, 0.22)
        sm.sky_horizon_color = Color(0.30, 0.36, 0.50)
        sm.ground_bottom_color = Color(0.08, 0.09, 0.12)
        sm.ground_horizon_color = Color(0.16, 0.19, 0.26)
        var sky := Sky.new()
        sky.sky_material = sm
        env.sky = sky
        env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
        env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
        var we := WorldEnvironment.new()
        we.environment = env
        showcase.add_child(we)

        var sun := DirectionalLight3D.new()
        sun.light_color = Color(1.0, 0.9, 0.8)
        sun.light_energy = 1.3
        sun.shadow_enabled = bool(GameState.settings["shadows"])
        showcase.add_child(sun)
        sun.rotation = Vector3(deg_to_rad(-38), deg_to_rad(30), 0)

        var floor_body := StaticBody3D.new()
        showcase.add_child(floor_body)
        var fm := Assets.mat("dark_metal")
        var cs := CollisionShape3D.new()
        var sh := BoxShape3D.new()
        sh.size = Vector3(30, 0.4, 30)
        cs.shape = sh
        floor_body.add_child(cs)
        var fl := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(30, 0.4, 30)
        fl.mesh = bm
        fl.material_override = Assets.plastic(Color(0.13, 0.15, 0.20))
        floor_body.add_child(fl)
        fl.position = Vector3(0, -0.2, 0)
        var ring := Assets.torus(showcase, Vector3(0, 0.03, 0), 3.4, 3.2, Assets.plastic(Color(0.9, 0.45, 0.1)))
        ring.rotation = Vector3(0, 0, 0)

        turntable = Node3D.new()
        showcase.add_child(turntable)
        turntable.position = Vector3(0, 0, 0)
        var chassis := Node3D.new()
        chassis.position.y = 0.588   # bike model space has ground at local y = -0.588
        turntable.add_child(chassis)
        var bb := BikeBuilder.new()
        var refs: Dictionary = bb.build(chassis, GameState.current_bike, GameState.bike_custom(GameState.current_bike))
        var rb := RiderBuilder.new()
        var rig: Dictionary = rb.build(chassis, GameState.bike_custom(GameState.current_bike))
        # static neutral pose on the podium
        _pose_showcase(rig, refs)

        cam = Camera3D.new()
        showcase.add_child(cam)
        cam.position = Vector3(0.4, 1.15, 4.3)
        cam.rotation = Vector3(0, 0, 0)
        cam.current = true

func _pose_showcase(rig: Dictionary, refs: Dictionary) -> void:
        # place wheels and rider into a parked stance (chassis space +0.588)
        var F := turntable
        var pelvis := F.to_global(Vector3(-0.06, 0.888, 0))
        rig["pelvis"].global_transform = Transform3D(Basis(), pelvis)
        rig["torso"].global_transform = Transform3D(Basis(Vector3(0, 0, 1), 0.2), pelvis + Vector3(0, 0.08, 0))
        var spine := 0.2
        var shoulder := pelvis + Vector3(0, 0.08, 0) + Vector3(cos(spine), sin(spine), 0) * 0.20
        var bar_l: Vector3 = refs["bar_l"].global_position
        var bar_r: Vector3 = refs["bar_r"].global_position
        rig["head"].global_transform = Transform3D(Basis(Vector3(0, 0, 1), 0.5), pelvis + Vector3(0, 0.08, 0) + Vector3(cos(spine), sin(spine), 0) * 0.30)
        _ik_static(rig["ua_l"], rig["fa_l"], rig["hand_l"], shoulder + Vector3(0, 0, -0.10), bar_l, 0.26, 0.24)
        _ik_static(rig["ua_r"], rig["fa_r"], rig["hand_r"], shoulder + Vector3(0, 0, 0.10), bar_r, 0.26, 0.24)
        var peg_l: Vector3 = refs["peg_l"].global_position
        var peg_r: Vector3 = refs["peg_r"].global_position
        var hip := pelvis
        _ik_static(rig["th_l"], rig["sh_l"], rig["foot_l"], hip + Vector3(0, 0, -0.075), peg_l, 0.32, 0.32)
        _ik_static(rig["th_r"], rig["sh_r"], rig["foot_r"], hip + Vector3(0, 0, 0.075), peg_r, 0.32, 0.32)

func _ik_static(upper: Node3D, lower: Node3D, end_n: Node3D, s: Vector3, t: Vector3, l1: float, l2: float) -> void:
        var s2 := Vector2(s.x, s.y)
        var t2 := Vector2(t.x, t.y)
        var dd := clampf((t2 - s2).length(), absf(l1 - l2) + 0.02, l1 + l2 - 0.02)
        var theta := atan2(t2.y - s2.y, t2.x - s2.x)
        var cs := clampf((l1 * l1 + dd * dd - l2 * l2) / (2.0 * l1 * dd), -1.0, 1.0)
        var a1 := theta + acos(cs)
        var elbow := Vector2(s2.x + cos(a1) * l1, s2.y + sin(a1) * l1)
        var a2 := atan2(t2.y - elbow.y, t2.x - elbow.x)
        var end2 := elbow + Vector2(cos(a2), sin(a2)) * l2
        upper.global_transform = Transform3D(Basis(Vector3(0, 0, 1), a1), Vector3(s2.x, s2.y, s.z))
        lower.global_transform = Transform3D(Basis(Vector3(0, 0, 1), a2), Vector3(elbow.x, elbow.y, s.z))
        end_n.global_transform = Transform3D(Basis(Vector3(0, 0, 1), a2), Vector3(end2.x, end2.y, s.z))

func _process(dt: float) -> void:
        if turntable:
                turntable.rotation.y += dt * 0.45

# ---------------------------------------------------------------- UI
func _build_ui() -> void:
        ui = CanvasLayer.new()
        add_child(ui)

        var dim := ColorRect.new()
        dim.color = Color(0.02, 0.03, 0.06, 0.35)
        dim.set_anchors_preset(Control.PRESET_FULL_RECT)
        dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
        ui.add_child(dim)

        var left := VBoxContainer.new()
        left.set_anchors_preset(Control.PRESET_CENTER_LEFT)
        left.anchor_left = 0.06
        left.anchor_right = 0.34
        left.anchor_top = 0.08
        left.anchor_bottom = 0.95
        left.add_theme_constant_override("separation", 14)
        ui.add_child(left)

        var title := UIB.label("NoomiStunt", 96, Color(1.0, 0.62, 0.15), 10)
        left.add_child(title)
        left.add_child(UIB.label("PITBIKE STUNT SIMULATOR", 26, Color(0.9, 0.92, 1.0), 5))
        left.add_child(UIB.label("", 8))

        var prof := UIB.panel(Color(0.08, 0.11, 0.17, 0.8), Color(1, 1, 1, 0.3), 16)
        left.add_child(prof)
        var pv := VBoxContainer.new()
        prof.add_child(pv)
        profile_lbl = UIB.label("", 26)
        pv.add_child(profile_lbl)
        xp_bar = ProgressBar.new()
        xp_bar.custom_minimum_size = Vector2(0, 14)
        xp_bar.show_percentage = false
        pv.add_child(xp_bar)

        var bplay := UIB.button("ИГРАТЬ", 44, _open_maps)
        bplay.custom_minimum_size = Vector2(0, 74)
        left.add_child(bplay)
        var bgar := UIB.button("ГАРАЖ", 34, func(): get_tree().change_scene_to_file("res://scenes/garage.tscn"))
        bgar.custom_minimum_size = Vector2(0, 62)
        left.add_child(bgar)
        var brec := UIB.button("РЕКОРДЫ", 34, _open_records)
        brec.custom_minimum_size = Vector2(0, 62)
        left.add_child(brec)
        var bset := UIB.button("НАСТРОЙКИ", 34, _open_settings)
        bset.custom_minimum_size = Vector2(0, 62)
        left.add_child(bset)
        var bhelp := UIB.button("УПРАВЛЕНИЕ", 34, _open_help)
        bhelp.custom_minimum_size = Vector2(0, 62)
        left.add_child(bhelp)

        var ver := UIB.label("Версия %d · Godot 4.3 · Mobile Renderer" % GameState.VERSION, 20, Color(1, 1, 1, 0.6), 4)
        ver.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
        ver.position = Vector2(20, 1040)
        ui.add_child(ver)

        _refresh_profile()
        _build_popups()

func _refresh_profile() -> void:
        profile_lbl.text = "Уровень %d   ·   %d монет" % [GameState.level, GameState.coins]
        var base := 300.0 * float(GameState.level - 1) * float(GameState.level - 1)
        var next := 300.0 * float(GameState.level) * float(GameState.level)
        var f := clampf((float(GameState.xp) - base) / maxf(1.0, next - base), 0.0, 1.0)
        xp_bar.value = f * 100.0

func _build_popups() -> void:
        var root_holder := Control.new()
        root_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
        ui.add_child(root_holder)
        popups["holder"] = root_holder

        # maps
        var mp := _popup_base("ВЫБОР КАРТЫ")
        var v: VBoxContainer = mp.get_child(0).get_child(0)
        for mid in ["park", "dirt", "urban"]:
                var data: Dictionary = MapData.MAPS[mid]
                var row := HBoxContainer.new()
                row.add_theme_constant_override("separation", 10)
                v.add_child(row)
                var info := UIB.panel(Color(0.08, 0.11, 0.17, 0.85), Color(1, 1, 1, 0.28), 14)
                info.custom_minimum_size = Vector2(560, 110)
                row.add_child(info)
                var iv := VBoxContainer.new()
                info.add_child(iv)
                iv.add_child(UIB.label(String(data["name"]), 32, Color(0.9, 0.95, 1.0)))
                if GameState.map_unlocked(mid):
                        var bt := GameState.record_time(mid)
                        var bs := GameState.record_score(mid)
                        var stxt := "Рекорд времени: %s" % _fmt_t(bt) if bt > 0 else "Рекорд времени: —"
                        iv.add_child(UIB.label(stxt, 22, Color(1.0, 0.85, 0.4), 4))
                        iv.add_child(UIB.label("Рекорд очков: %d" % bs, 22, Color(0.6, 1.0, 0.7), 4))
                else:
                        var req: Dictionary = GameState.MAP_UNLOCK[mid]
                        iv.add_child(UIB.label("ЗАБЛОКИРОВАНО · %d монет или уровень %d" % [int(req["coins"]), int(req["level"])], 22, Color(1.0, 0.55, 0.5), 4))
                if GameState.map_unlocked(mid):
                        var sel := UIB.button("ВЫБРАТЬ", 26, _pick.bind(mid))
                        sel.custom_minimum_size = Vector2(170, 96)
                        row.add_child(sel)
                else:
                        var unl := UIB.button("РАЗБЛОКИРОВАТЬ", 22, _unlock.bind(mid))
                        unl.custom_minimum_size = Vector2(240, 96)
                        row.add_child(unl)
        var cl := UIB.button("ЗАКРЫТЬ", 26, _open_popup.bind(""))
        mp.get_child(0).get_child(0).add_child(cl)
        popups["maps"] = mp

        # records
        var rp := _popup_base("РЕКОРДЫ")
        var rv: VBoxContainer = rp.get_child(0).get_child(0)
        rv.add_child(UIB.label("Всего очков в профиле: уровень %d, монет %d" % [GameState.level, GameState.coins], 24, Color(0.8, 0.9, 1.0), 4))
        for mid2 in ["park", "dirt", "urban"]:
                var d2: Dictionary = MapData.MAPS[mid2]
                var bt2 := GameState.record_time(mid2)
                var bs2 := GameState.record_score(mid2)
                var locked := not GameState.map_unlocked(mid2)
                var line := "%s — время: %s · очки: %d%s" % [String(d2["name"]), _fmt_t(bt2) if bt2 > 0 else "—", bs2, "  (закрыта)" if locked else ""]
                rv.add_child(UIB.label(line, 26, Color(0.95, 0.95, 0.95), 4))
        var cl2 := UIB.button("ЗАКРЫТЬ", 26, _open_popup.bind(""))
        rp.get_child(0).get_child(0).add_child(cl2)
        popups["records"] = rp

        # settings
        var sp := _popup_base("НАСТРОЙКИ")
        var sv: VBoxContainer = sp.get_child(0).get_child(0)
        sv.add_child(SettingsPanel.build(Callable()))
        var cl3 := UIB.button("ЗАКРЫТЬ", 26, _open_popup.bind(""))
        sp.get_child(0).get_child(0).add_child(cl3)
        popups["settings"] = sp

        # help
        var hp := _popup_base("УПРАВЛЕНИЕ")
        var hv: VBoxContainer = hp.get_child(0).get_child(0)
        var lines := [
                "ЛЕВАЯ ЧАСТЬ ЭКРАНА:",
                "ГАЗ — разгон   ·   ПЕРЕДНИЙ/ЗАДНИЙ ТОРМОЗ — торможение и стоппи",
                "ПОВОРОТ ← / → — наклон мотоцикла (баланс и вращение в воздухе)",
                "ВИЛЛИ — удержание вилли   ·   ДРИФТ — пробуксовка заднего колеса",
                "СБРОС — вернуться на трассу   ·   МЕНЮ — пауза",
                "",
                "ПРАВАЯ ЧАСТЬ (вкладки):",
                "РУКИ И НОГИ — отпускать конечности и держать их",
                "ТРЮКИ — CAN CAN, NAC NAC, SUPERMAN, HEEL CLICKER, WHIP, BACKFLIP, 360",
                "ПРО — SUPERMAN SEAT GRAB, INDIAN AIR, BAR HOP, LAZY BOY, COFFIN, ROCK SOLID",
                "",
                "Клавиатура: W газ, S задний тормоз, Space передний, A/D наклон,",
                "Q вилли, E дрифт, R сброс, Esc пауза, 1-9/0/Z X C — трюки.",
                "",
                "СЕКУНДЫ СТАНТА идут, пока вы удерживаете трюк/вилли.",
                "Падение обнуляет серию. Безопасное завершение серии сохраняет рекорд.",
        ]
        for ln in lines:
                hv.add_child(UIB.label(ln, 22, Color(0.92, 0.94, 1.0), 3))
        var cl4 := UIB.button("ЗАКРЫТЬ", 26, _open_popup.bind(""))
        hp.get_child(0).get_child(0).add_child(cl4)
        popups["help"] = hp

func _popup_base(title: String) -> PanelContainer:
        var holder := Control.new()
        holder.set_anchors_preset(Control.PRESET_FULL_RECT)
        holder.visible = false
        ui.add_child(holder)
        var dim := ColorRect.new()
        dim.color = Color(0, 0, 0, 0.6)
        dim.set_anchors_preset(Control.PRESET_FULL_RECT)
        holder.add_child(dim)
        var p := UIB.panel(Color(0.07, 0.10, 0.15, 0.96), Color(1, 1, 1, 0.4), 22)
        holder.add_child(p)
        var sc := ScrollContainer.new()
        p.add_child(sc)
        sc.custom_minimum_size = Vector2(920, 640)
        var v := VBoxContainer.new()
        v.add_theme_constant_override("separation", 12)
        sc.add_child(v)
        v.add_child(UIB.label(title, 44, Color(1.0, 0.7, 0.2)))
        p.set_anchors_preset(Control.PRESET_CENTER)
        p.position = Vector2(960 - 480, 540 - 340)
        return p

func _open_popup(name: String) -> void:
        for k in popups.keys():
                if k == "holder":
                        continue
                popups[k].visible = (k == name)
        _refresh_profile()

func _open_maps() -> void:
        AudioMan.click()
        _open_popup("maps")

func _open_records() -> void:
        AudioMan.click()
        _open_popup("records")

func _open_settings() -> void:
        AudioMan.click()
        _open_popup("settings")

func _open_help() -> void:
        AudioMan.click()
        _open_popup("help")

func _pick(mid: String) -> void:
        GameState.current_map = mid
        GameState.save_game()
        get_tree().change_scene_to_file("res://scenes/game.tscn")

func _unlock(mid: String) -> void:
        AudioMan.click()
        if GameState.try_unlock_map(mid):
                AudioMan.coin()
                _open_maps()
        else:
                _refresh_profile()

@warning_ignore("integer_division")
func _fmt_t(t: float) -> String:
        var s := int(floor(t))
        var d := int((t - float(s)) * 10.0)
        return "%d:%02d.%d" % [s / 60, s % 60, d]
