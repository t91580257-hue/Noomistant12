extends CanvasLayer
## Pause overlay in game: resume, restart, settings, back to menu.

signal restart_requested
signal menu_requested

const UIB := preload("res://scripts/ui/ui_builder.gd")
const SettingsPanel := preload("res://scripts/ui/settings_panel.gd")

var main_box: VBoxContainer
var settings_holder: Control

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 20
	visible = false

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var p: PanelContainer = UIB.panel(Color(0.09, 0.12, 0.18, 0.95), Color(1, 1, 1, 0.45), 22)
	p.custom_minimum_size = Vector2(560, 0)
	center.add_child(p)
	main_box = VBoxContainer.new()
	main_box.add_theme_constant_override("separation", 14)
	p.add_child(main_box)
	main_box.add_child(UIB.label("ПАУЗА", 52))
	var resume := UIB.button("ПРОДОЛЖИТЬ", 36, close)
	resume.custom_minimum_size = Vector2(460, 64)
	main_box.add_child(resume)
	var restart := UIB.button("ЗАНОВО", 36, func():
		close()
		restart_requested.emit())
	restart.custom_minimum_size = Vector2(460, 64)
	main_box.add_child(restart)
	var st := UIB.button("НАСТРОЙКИ", 36, _toggle_settings)
	st.custom_minimum_size = Vector2(460, 64)
	main_box.add_child(st)
	var menu := UIB.button("В ГЛАВНОЕ МЕНЮ", 36, func():
		get_tree().paused = false
		menu_requested.emit())
	menu.custom_minimum_size = Vector2(460, 64)
	main_box.add_child(menu)

	settings_holder = Control.new()
	settings_holder.visible = false
	settings_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(settings_holder)
	var sp: PanelContainer = SettingsPanel.build(Callable())
	settings_holder.add_child(sp)
	sp.set_anchors_preset(Control.PRESET_CENTER)
	sp.position = Vector2(960 - 320, 120)

func _toggle_settings() -> void:
	settings_holder.visible = not settings_holder.visible
	main_box.get_parent().visible = not settings_holder.visible

func open() -> void:
	get_tree().paused = true
	settings_holder.visible = false
	main_box.get_parent().visible = true
	visible = true

func close() -> void:
	get_tree().paused = false
	visible = false

func _input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("pause"):
		if settings_holder.visible:
			settings_holder.visible = false
			main_box.get_parent().visible = true
		else:
			close()
		get_viewport().set_input_as_handled()
