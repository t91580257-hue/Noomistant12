extends RefCounted
## Builds a full 3D map: environment (sky/sun/fog), terrain from MapData,
## decorations, walls and the start gate.

var A: AssetLib

func build(root: Node3D, map_id: String, quality: Dictionary) -> Dictionary:
        A = Assets
        var data: Dictionary = MapData.MAPS[map_id]

        # ---------------- environment
        var env := Environment.new()
        env.background_mode = Environment.BG_SKY
        var sky_mat := ProceduralSkyMaterial.new()
        sky_mat.sky_top_color = data["sky_top"]
        sky_mat.sky_horizon_color = data["sky_horizon"]
        sky_mat.sky_energy_multiplier = 1.0
        sky_mat.ground_bottom_color = data["ground_hor"]
        sky_mat.ground_horizon_color = data["ground_col"]
        var sky := Sky.new()
        sky.sky_material = sky_mat
        env.sky = sky
        env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
        env.ambient_light_energy = 1.0
        env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
        env.fog_enabled = true
        env.fog_light_color = data["sky_horizon"]
        env.fog_density = 0.004
        env.fog_sky_affect = 0.1
        var we := WorldEnvironment.new()
        we.environment = env
        root.add_child(we)

        var sun := DirectionalLight3D.new()
        sun.light_color = data["sun_color"]
        sun.light_energy = 1.25
        sun.shadow_enabled = bool(quality.get("shadows", true))
        sun.directional_shadow_max_distance = 55.0
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
        sun.shadow_bias = 0.35
        sun.shadow_normal_bias = 2.5
        root.add_child(sun)
        sun.rotation = Vector3(deg_to_rad(-42.0), deg_to_rad(float(data["sun_yaw"])), 0)

        # ---------------- terrain
        var terr := Node3D.new()
        terr.name = "Terrain"
        root.add_child(terr)
        for g in data["grounds"]:
                var thick := 1.4
                var h := float(g.get("h", thick))
                if g.has("h"):
                        A.add_static_box(terr, Vector3(float(g["x"]), float(g["y"]) - h / 2.0, 0), Vector3(float(g["w"]), h, 3.2), A.mat(g["s"]), g["s"])
                else:
                        var cy := float(g["y"]) - thick / 2.0
                        A.add_static_box(terr, Vector3(float(g["x"]), cy, 0), Vector3(float(g["w"]), thick, 3.2), A.mat(g["s"]), g["s"])
                # grass strip on top of dirt grounds for park
                if map_id == "park" and g["s"] == "dirt" and float(g["w"]) > 3.0:
                        var m2 := A.mat("grass")
                        var strip := A.box(terr, Vector3(float(g["x"]), float(g["y"]) + 0.02, -1.3), Vector3(float(g["w"]) - 0.2, 0.04, 0.7), m2)
                        strip.position.z = -1.3
        for r in data["ramps"]:
                A.add_static_wedge(terr, Vector3(float(r["x"]), float(r["y"]), 0), float(r["w"]), float(r["h"]), 3.0, int(r["dir"]), A.mat(r["s"]), r["s"])
        for g2 in data["grounds"]:
                if g2.has("h") and g2["s"] == "metal":
                        A.box(terr, Vector3(float(g2["x"]), float(g2["y"]) - 0.03, 1.35), Vector3(float(g2["w"]) - 0.3, 0.06, 0.5), A.mat("chrome"))

        # ---------------- walls
        A.add_static_box(terr, Vector3(-13.0, 3.0, 0), Vector3(1.0, 8.0, 3.0), A.mat("concrete"), "concrete")
        A.add_static_box(terr, Vector3(float(data["len"]) + 3.0, 3.0, 0), Vector3(1.0, 8.0, 3.0), A.mat("concrete"), "concrete")

        # ---------------- start gate
        var gate := Node3D.new()
        terr.add_child(gate)
        var gm := A.mat("dark_metal")
        A.tube(gate, Vector3(0, 0, -2.6), Vector3(0, 3.0, -2.6), 0.06, gm)
        A.tube(gate, Vector3(0, 0, 2.6), Vector3(0, 3.0, 2.6), 0.06, gm)
        A.tube(gate, Vector3(0, 3.0, -2.7), Vector3(0, 3.0, 2.7), 0.05, gm)
        A.quad(gate, Vector3(0, 2.5, 0), Vector2(5.4, 1.1), data["banner"])

        # ---------------- decor
        _decor(terr, map_id, data)

        return {"spawn": Transform3D(Basis(), Vector3(2.0, 1.2, 0)), "data": data, "sun": sun}

func _decor(root: Node3D, map_id: String, data: Dictionary) -> void:
        var rng := RandomNumberGenerator.new()
        rng.seed = hash(map_id)
        var l := float(data["len"])
        # clouds
        for i in range(9):
                var c := A.quad(root, Vector3(rng.randf_range(-10, l + 10), rng.randf_range(7.5, 14.0), -26.0), Vector2(rng.randf_range(6, 11), rng.randf_range(3, 5.5)), "cloud")
                c.set_meta("drift", rng.randf_range(0.2, 0.7))
        # backdrops
        if map_id == "urban":
                A.quad(root, Vector3(l / 2.0, 5.5, -18.0), Vector2(l + 60, 11.0), "city")
                A.quad(root, Vector3(l / 2.0 - 20, 4.0, -34.0), Vector2(l + 100, 8.0), "city")
        else:
                A.quad(root, Vector3(l / 2.0, 2.2, -20.0), Vector2(l + 60, 4.4), "hill_green" if map_id == "park" else "hill_blue")
                A.quad(root, Vector3(l / 2.0, 3.4, -36.0), Vector2(l + 80, 6.8), "hill_blue")
        # flags along track
        var flag_mats := ["flag_red", "flag_blue", "flag_yellow"]
        var x := 8.0
        var fi := 0
        while x < l:
                _flag(root, Vector3(x, 0, rng.randf_range(-2.2, -4.5)), flag_mats[fi % 3], rng.randf_range(1.0, 1.8))
                x += rng.randf_range(11.0, 17.0)
                fi += 1
        if map_id == "park":
                for i in range(10):
                        _tree(root, Vector3(rng.randf_range(-8, l), 0, rng.randf_range(-7, -14)), rng.randf_range(1.6, 2.6))
                for i in range(6):
                        _tires(root, Vector3(rng.randf_range(8, l), 0, rng.randf_range(-2.0, -3.4)))
                for i in range(12):
                        _cone(root, Vector3(rng.randf_range(4, 28), 0, rng.randf_range(0.6, 1.1)))
        elif map_id == "dirt":
                for i in range(12):
                        _tree(root, Vector3(rng.randf_range(-8, l), 0, rng.randf_range(-8, -15)), rng.randf_range(1.4, 2.2))
                for i in range(8):
                        _tires(root, Vector3(rng.randf_range(10, l), 0, rng.randf_range(-2.0, -3.6)))
        else:
                for i in range(8):
                        var bx := rng.randf_range(6, l - 8)
                        var bm := A.mat("container") if rng.randf() < 0.5 else A.mat("container_red")
                        A.box(root, Vector3(bx, 1.25, rng.randf_range(-6.0, -10.0)), Vector3(6.0, 2.5, 2.5), bm)
                for i in range(14):
                        _cone(root, Vector3(rng.randf_range(70, 84), 0, rng.randf_range(0.5, 1.2)))

func _flag(root: Node3D, pos: Vector3, mname: String, h: float) -> void:
        A.tube(root, pos, pos + Vector3(0, h, 0), 0.025, A.mat("dark_metal"))
        var f := A.box(root, pos + Vector3(0.28, h - 0.2, 0), Vector3(0.55, 0.34, 0.02), A.mat(mname))
        f.rotation = Vector3(0, 0.3, 0)

func _tree(root: Node3D, pos: Vector3, h: float) -> void:
        A.tube(root, pos, pos + Vector3(0, h * 0.55, 0), 0.09, A.mat("wood"))
        A.sphere(root, pos + Vector3(0, h * 0.75, 0), h * 0.42, A.mat("grass"), Vector3(1.0, 1.15, 1.0))
        A.sphere(root, pos + Vector3(0.12, h * 0.95, 0.05), h * 0.30, A.mat("grass"), Vector3(1.1, 1.0, 1.1))

func _tires(root: Node3D, pos: Vector3) -> void:
        for i in range(3):
                A.torus(root, pos + Vector3(0, 0.13 + i * 0.24, 0), 0.30, 0.15, A.mat("tire_stack"), PI / 2)

func _cone(root: Node3D, pos: Vector3) -> void:
        var node := MeshInstance3D.new()
        var mesh := CylinderMesh.new()
        mesh.top_radius = 0.02
        mesh.bottom_radius = 0.10
        mesh.height = 0.30
        node.mesh = mesh
        node.material_override = A.mat("cone")
        root.add_child(node)
        node.position = pos + Vector3(0, 0.15, 0)
