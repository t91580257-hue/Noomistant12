extends Node3D
## Rider rig animation. All joints are animated with analytic 2-bone IK in the
## yaw-frame local space, so tricks read correctly from the fixed side camera.

var bike: RigidBody3D
var frame: Node3D          # all_yaw node (local space = animation space)
var refs := {}             # rider limb nodes
var brefs := {}            # bike markers (bar/peg/seat)
var L := {"ua": 0.26, "fa": 0.24, "th": 0.32, "sh": 0.32}

# current (smoothed) pose values
var _pelvis_off := Vector3.ZERO
var _spine := 0.25
var _head := 0.35
var _head_yaw := 0.0
var _targets := {"hand_l": Vector3.ZERO, "hand_r": Vector3.ZERO, "foot_l": Vector3.ZERO, "foot_r": Vector3.ZERO}
var _pose_id := "ride"
var _has_targets := {}

func setup(bike_body: RigidBody3D, anim_frame: Node3D, rig: Dictionary, bike_marks: Dictionary) -> void:
        bike = bike_body
        frame = anim_frame
        refs = rig
        brefs = bike_marks
        L = rig["len"]
        _pelvis_off = Vector3.ZERO

func apply_state(st: Dictionary) -> void:
        _pose_id = st.get("pose", "ride")

func crash_pose() -> void:
        _pose_id = "crash"

func _pose() -> Dictionary:
        var p: Dictionary = (PoseLib.POSES["ride"] as Dictionary).duplicate()
        if _pose_id != "ride" and PoseLib.POSES.has(_pose_id):
                var ov: Dictionary = PoseLib.POSES[_pose_id]
                for k in ov.keys():
                        p[k] = ov[k]
        return p

func update(dt: float, st: Dictionary) -> void:
        if frame == null:
                return
        var pose := _pose()
        var F_inv := frame.global_transform.affine_inverse()

        # ------- desired values
        var d_pelvis := _vec(pose.get("pelvis", [0.0, 0.0, 0.0]))
        var d_spine := float(pose.get("spine", 0.25))
        var d_head := float(pose.get("head", 0.35))
        var d_yaw := float(pose.get("head_yaw", 0.0))

        # ------- limb targets (bike-local offsets -> frame-local points)
        var peg_l: Vector3 = F_inv * (brefs["peg_l"] as Node3D).global_position
        var peg_r: Vector3 = F_inv * (brefs["peg_r"] as Node3D).global_position
        var bar_l: Vector3 = F_inv * (brefs["bar_l"] as Node3D).global_position
        var bar_r: Vector3 = F_inv * (brefs["bar_r"] as Node3D).global_position

        var want := {
                "hand_l": bar_l, "hand_r": bar_r,
                "foot_l": peg_l, "foot_r": peg_r,
        }
        var has := {"hand_l": false, "hand_r": false, "foot_l": false, "foot_r": false}
        if pose.has("hand_l"):
                want["hand_l"] = _to_frame(pelvis_base() + _vec(pose["hand_l"]), F_inv)
                has["hand_l"] = true
        if pose.has("hand_r"):
                want["hand_r"] = _to_frame(pelvis_base() + _vec(pose["hand_r"]), F_inv)
                has["hand_r"] = true
        if pose.has("foot_l"):
                want["foot_l"] = _to_frame(pelvis_base() + _vec(pose["foot_l"]), F_inv)
                has["foot_l"] = true
        if pose.has("foot_r"):
                want["foot_r"] = _to_frame(pelvis_base() + _vec(pose["foot_r"]), F_inv)
                has["foot_r"] = true

        # ------- smooth everything
        var k := minf(1.0, dt * 9.0)
        _pelvis_off = _pelvis_off.lerp(d_pelvis, k)
        _spine = lerpf(_spine, d_spine, k)
        _head = lerpf(_head, d_head, k)
        _head_yaw = lerpf(_head_yaw, d_yaw, k)
        for key in want.keys():
                _targets[key] = _targets[key].lerp(want[key], k)
        _has_targets = has

        # ------- body chain (frame-local)
        var p_b := pelvis_base() + _pelvis_off
        var pelvis_p := _to_frame(p_b, F_inv)
        var spine_dir := Vector3(cos(_spine), sin(_spine), 0)
        var torso_p := pelvis_p + Vector3(0, 0.08, 0)
        var shoulder_c := torso_p + spine_dir * 0.20
        var head_p := torso_p + spine_dir * 0.30
        var hip_l := pelvis_p + Vector3(0, 0, -0.075)
        var hip_r := pelvis_p + Vector3(0, 0, 0.075)

        _set_node(refs["pelvis"], pelvis_p, 0.0)
        _set_node(refs["torso"], torso_p, _spine)
        var hb := Basis(Vector3(0, 0, 1), _spine + _head) * Basis(Vector3(0, 1, 0), _head_yaw)
        refs["head"].transform = Transform3D(hb, head_p)

        # ------- arms IK
        var sh_l := shoulder_c + Vector3(0, 0, -0.10)
        var sh_r := shoulder_c + Vector3(0, 0, 0.10)
        _ik2(refs["ua_l"], refs["fa_l"], refs["hand_l"], sh_l, _targets["hand_l"], L["ua"], L["fa"], 1.0)
        _ik2(refs["ua_r"], refs["fa_r"], refs["hand_r"], sh_r, _targets["hand_r"], L["ua"], L["fa"], 1.0)

        # ------- legs IK (knee forward)
        _ik2(refs["th_l"], refs["sh_l"], refs["foot_l"], hip_l, _targets["foot_l"], L["th"], L["sh"], 1.0)
        _ik2(refs["th_r"], refs["sh_r"], refs["foot_r"], hip_r, _targets["foot_r"], L["th"], L["sh"], 1.0)

func pelvis_base() -> Vector3:
        return Vector3(-0.06, 0.30, 0)

func _to_frame(p_bike_local: Vector3, F_inv: Transform3D) -> Vector3:
        return F_inv * bike.to_global(p_bike_local)

func _vec(a: Array) -> Vector3:
        return Vector3(float(a[0]), float(a[1]), float(a[2]))

func _set_node(n: Node3D, pos: Vector3, rot_z: float) -> void:
        n.transform = Transform3D(Basis(Vector3(0, 0, 1), rot_z), pos)

func _ik2(upper: Node3D, lower: Node3D, end_n: Node3D, s: Vector3, tgt: Vector3, l1: float, l2: float, sign: float) -> void:
        var z := s.z
        var s2 := Vector2(s.x, s.y)
        var t2 := Vector2(tgt.x, tgt.y)
        var dd := clampf((t2 - s2).length(), absf(l1 - l2) + 0.02, l1 + l2 - 0.02)
        var theta := atan2(t2.y - s2.y, t2.x - s2.x)
        var cs := clampf((l1 * l1 + dd * dd - l2 * l2) / (2.0 * l1 * dd), -1.0, 1.0)
        var delta := acos(cs) * sign
        var a1 := theta + delta
        var elbow := Vector2(s2.x + cos(a1) * l1, s2.y + sin(a1) * l1)
        var a2 := atan2(t2.y - elbow.y, t2.x - elbow.x)
        var end2 := elbow + Vector2(cos(a2), sin(a2)) * l2
        _set_node(upper, Vector3(s2.x, s2.y, z), a1)
        _set_node(lower, Vector3(elbow.x, elbow.y, z), a2)
        end_n.transform = Transform3D(Basis(Vector3(0, 0, 1), a2), Vector3(end2.x, end2.y, z))

func hands_on_bars() -> Array:
        var pose := _pose()
        return [not pose.has("hand_l"), not pose.has("hand_r")]

func feet_on_pegs() -> Array:
        var pose := _pose()
        return [not pose.has("foot_l"), not pose.has("foot_r")]
