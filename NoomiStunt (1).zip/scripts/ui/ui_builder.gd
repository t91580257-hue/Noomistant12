extends RefCounted
## UI factory: styled labels, panels, buttons, touch buttons (multitouch).

static func label(text: String, size: int, color := Color(1, 1, 1), outline := 6) -> Label:
        var l := Label.new()
        l.text = text
        l.add_theme_font_size_override("font_size", size)
        l.add_theme_color_override("font_color", color)
        if outline > 0:
                l.add_theme_constant_override("outline_size", outline)
                l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.75))
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        l.mouse_filter = Control.MOUSE_FILTER_IGNORE
        return l

static func panel_style(bg := Color(1, 1, 1, 0.10), border := Color(1, 1, 1, 0.32), radius := 18, bw := 2) -> StyleBoxFlat:
        var sb := StyleBoxFlat.new()
        sb.bg_color = bg
        sb.border_color = border
        sb.set_border_width_all(bw)
        sb.set_corner_radius_all(radius)
        sb.set_content_margin_all(12)
        return sb

static func panel(bg := Color(1, 1, 1, 0.10), border := Color(1, 1, 1, 0.32), radius := 18) -> PanelContainer:
        var p := PanelContainer.new()
        p.add_theme_stylebox_override("panel", panel_style(bg, border, radius))
        return p

static func button(text: String, size: int, cb: Callable, bg := Color(1, 1, 1, 0.14)) -> Button:
        var b := Button.new()
        b.text = text
        b.add_theme_font_size_override("font_size", size)
        b.add_theme_color_override("font_color", Color(1, 1, 1))
        b.add_theme_color_override("font_hover_color", Color(0.85, 0.95, 1.0))
        b.add_theme_color_override("font_pressed_color", Color(0.6, 0.9, 1.0))
        b.add_theme_stylebox_override("normal", panel_style(bg, Color(1, 1, 1, 0.35), 14))
        b.add_theme_stylebox_override("hover", panel_style(Color(1, 1, 1, 0.22), Color(1, 1, 1, 0.5), 14))
        b.add_theme_stylebox_override("pressed", panel_style(Color(0.4, 0.7, 1.0, 0.3), Color(0.7, 0.9, 1.0, 0.7), 14))
        b.add_theme_stylebox_override("focus", panel_style(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 14))
        b.pressed.connect(func():
                AudioMan.click()
                cb.call())
        return b

## TouchScreenButton wrapper: multitouch hold, label centered.
## Returns wrapper Node2D (position = center of button).
static func touch_btn(action: String, text: String, radius: float, alpha := 0.5) -> Node2D:
        var wrap := Node2D.new()
        var b := TouchScreenButton.new()
        b.texture_normal = Assets.t("btn")
        b.texture_pressed = Assets.t("btn_on")
        b.scale = Vector2.ONE * (radius * 2.0 / 160.0)
        b.position = Vector2(-radius, -radius)
        b.action = action
        b.passby_press = false
        b.modulate = Color(1, 1, 1, alpha)
        wrap.add_child(b)
        var l := Label.new()
        l.text = text
        var fs := int(radius * 0.34)
        if text.find("\n") >= 0:
                fs = int(radius * 0.26)
        elif text.length() > 8:
                fs = int(radius * 0.27)
        l.add_theme_font_size_override("font_size", fs)
        l.add_theme_color_override("font_color", Color(1, 1, 1, 0.95))
        l.add_theme_constant_override("outline_size", 5)
        l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        l.mouse_filter = Control.MOUSE_FILTER_IGNORE
        l.position = Vector2(-radius, -radius)
        l.size = Vector2(radius * 2.0, radius * 2.0)
        wrap.add_child(l)
        wrap.set_meta("tsb", b)
        wrap.set_meta("lbl", l)
        return wrap
