extends RefCounted
## Score system: points for tricks/air/duration, combo multipliers,
## repeat decay, pending points lost on crash. Separate from stunt seconds.

signal popup(text: String, color: Color)
signal score_changed(total: int, mult: int, pending: int)

var total := 0
var pending := 0
var distinct := {}         # trick ids used this chain
var _times_used := {}      # trick id -> count
var _map_id := "park"
var _best := 0

func setup(map_id: String, best: int) -> void:
	_map_id = map_id
	_best = best
	reset_chain()

func reset_chain() -> void:
	pending = 0
	distinct.clear()
	_times_used.clear()

func mult() -> int:
	var n := distinct.size()
	if n >= 10:
		return 10
	if n >= 7:
		return 5
	if n >= 4:
		return 3
	if n >= 2:
		return 2
	return 1

func award(trick_id: String) -> void:
	var t: Dictionary = TrickData.get_trick(trick_id)
	if t.is_empty():
		return
	var base := int(t["score"])
	var m := mult()
	distinct[trick_id] = true
	var used := int(_times_used.get(trick_id, 0)) + 1
	_times_used[trick_id] = used
	var decay := pow(0.5, used - 1)
	if decay < 0.125:
		decay = 0.125
	var pts := int(float(base) * float(m) * decay)
	pending += pts
	popup.emit("%s +%d" % [String(t["name"]), pts], Color(0.55, 1.0, 0.65))
	score_changed.emit(total, m, pending)

func add_air_bonus(air_time: float, height: float) -> void:
	var pts := int(air_time * 25.0 + height * 60.0)
	if pts > 0:
		pending += pts
		popup.emit("ПОЛЁТ +%d" % pts, Color(0.5, 0.8, 1.0))
		score_changed.emit(total, mult(), pending)

func bank(clean: bool) -> int:
	var gained := 0
	if pending > 0:
		var k := 1.15 if clean else 1.0
		gained = int(float(pending) * k)
		total += gained
		GameState.add_banked(gained)
		var is_record := GameState.submit_score(_map_id, total)
		popup.emit("+%d ОЧКОВ%s" % [gained, " · ЧИСТО!" if clean else ""], Color(1.0, 0.9, 0.4))
		if is_record and _best > 0:
			popup.emit("НОВЫЙ РЕКОРД ОЧКОВ!", Color(1.0, 0.75, 0.2))
	reset_chain()
	score_changed.emit(total, 1, 0)
	return gained

func lose() -> int:
	var lost := pending
	if lost > 0:
		popup.emit("-%d ОЧКОВ" % lost, Color(1.0, 0.35, 0.3))
	reset_chain()
	score_changed.emit(total, 1, 0)
	return lost
