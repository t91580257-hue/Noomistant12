class_name TrickData
## Trick definitions: activation rules, poses, scoring.
## air = only allowed while airborne; hold = seconds before it counts.

const TRICKS := {
        "t_lh": {"name": "ONE HANDER", "air": false, "score": 90, "hold": 0.25, "pose": "hang_l", "limb": "hl"},
        "t_rh": {"name": "ONE HANDER", "air": false, "score": 90, "hold": 0.25, "pose": "hang_r", "limb": "hr"},
        "t_hh": {"name": "NO HANDER", "air": false, "score": 200, "hold": 0.30, "pose": "hang_both", "limb": "hh"},
        "t_lf": {"name": "ONE FOOTER", "air": false, "score": 80, "hold": 0.25, "pose": "foot_l_off", "limb": "fl"},
        "t_rf": {"name": "ONE FOOTER", "air": false, "score": 80, "hold": 0.25, "pose": "foot_r_off", "limb": "fr"},
        "t_ff": {"name": "NO FOOTER", "air": true, "score": 180, "hold": 0.30, "pose": "feet_off", "limb": "ff"},
        "t_can": {"name": "CAN CAN", "air": true, "score": 260, "hold": 0.30, "pose": "cancan", "limb": "fr"},
        "t_nac": {"name": "NAC NAC", "air": true, "score": 280, "hold": 0.30, "pose": "nacnac", "limb": "fr"},
        "t_sup": {"name": "SUPERMAN", "air": true, "score": 420, "hold": 0.35, "pose": "superman", "limb": "ff"},
        "t_heel": {"name": "HEEL CLICKER", "air": true, "score": 380, "hold": 0.30, "pose": "heelclicker", "limb": "ff"},
        "t_look": {"name": "LOOKBACK", "air": false, "score": 70, "hold": 0.25, "pose": "lookback", "limb": ""},
        "t_ssg": {"name": "SUPERMAN SEAT GRAB", "air": true, "score": 620, "hold": 0.35, "pose": "ssg", "limb": "ff+hr"},
        "t_ind": {"name": "INDIAN AIR", "air": true, "score": 560, "hold": 0.35, "pose": "indian", "limb": "hh+ff"},
        "t_hop": {"name": "BAR HOP", "air": true, "score": 520, "hold": 0.35, "pose": "barhop", "limb": "ff"},
        "t_lazy": {"name": "LAZY BOY", "air": true, "score": 480, "hold": 0.35, "pose": "lazyboy", "limb": "ff+hl"},
        "t_cof": {"name": "COFFIN", "air": true, "score": 500, "hold": 0.35, "pose": "coffin", "limb": "hh+ff"},
        "t_rock": {"name": "ROCK SOLID", "air": true, "score": 640, "hold": 0.35, "pose": "rocksolid", "limb": "ff"},
        "t_whip": {"name": "WHIP", "air": true, "score": 240, "hold": 0.20, "pose": "ride", "limb": "", "yaw": true},
        "t_360": {"name": "360 SPIN", "air": true, "score": 700, "hold": 0.10, "pose": "ride", "limb": "", "spin": true},
        "t_flip": {"name": "BACKFLIP", "air": true, "score": 900, "hold": 0.10, "pose": "ride", "limb": "", "flip": true},
}

const AIR_ONLY := ["t_ff", "t_can", "t_nac", "t_sup", "t_heel", "t_ssg", "t_ind", "t_hop", "t_lazy", "t_cof", "t_rock", "t_whip", "t_360", "t_flip"]

## Tricks that must be RELEASED before touching the ground (limb/body poses).
## Whip/360/Backflip are judged by yaw/alignment instead.
const AIR_LIMB := ["t_ff", "t_can", "t_nac", "t_sup", "t_heel", "t_ssg", "t_ind", "t_hop", "t_lazy", "t_cof", "t_rock"]

const TABS := [
        {"id": 0, "label": "РУКИ И НОГИ", "actions": ["t_lh", "t_rh", "t_hh", "t_lf", "t_rf", "t_ff", "t_look"]},
        {"id": 1, "label": "ТРЮКИ", "actions": ["t_can", "t_nac", "t_sup", "t_heel", "t_whip", "t_flip", "t_360"]},
        {"id": 2, "label": "ПРО", "actions": ["t_ssg", "t_ind", "t_hop", "t_lazy", "t_cof", "t_rock"]},
]

const TRICK_LABELS := {
        "t_lh": "Л. РУКА", "t_rh": "П. РУКА", "t_hh": "2 РУКИ",
        "t_lf": "Л. НОГА", "t_rf": "П. НОГА", "t_ff": "2 НОГИ",
        "t_look": "LOOKBACK", "t_can": "CAN CAN", "t_nac": "NAC NAC",
        "t_sup": "SUPERMAN", "t_heel": "HEEL CLICK", "t_whip": "WHIP",
        "t_flip": "BACKFLIP", "t_360": "360",
        "t_ssg": "S-GRAB", "t_ind": "INDIAN", "t_hop": "BAR HOP",
        "t_lazy": "LAZY BOY", "t_cof": "COFFIN", "t_rock": "ROCK SOLID",
}

static func get_trick(id: String) -> Dictionary:
        return TRICKS.get(id, {})
