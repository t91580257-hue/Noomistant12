extends RefCounted
## Builds the motocross rider: articulated limbs, helmet, gear.
## Every limb is a real 3D capsule with proper proportions; joints are
## animated by IK from rider.gd (world-space targets).

const L_UA := 0.30   # upper arm
const L_FA := 0.27   # forearm
const L_TH := 0.32   # thigh
const L_SH := 0.32   # shin

func build(parent: Node3D, cst: Dictionary) -> Dictionary:
        var A := Assets
        var gear_col: Color = BikeData.GEAR_COLORS[int(cst.get("gear", 0))]
        var helmet_col: Color = BikeData.HELMET_COLORS[int(cst.get("helmet", 0))]
        var r := {}

        var jersey_r := A.gear(gear_col, 1.0)
        var jersey_l := A.gear(gear_col, 0.72)
        var pants_r := A.gear(gear_col * 0.55 + Color(0.05, 0.05, 0.07), 1.0)
        var pants_l := A.gear(gear_col * 0.55 + Color(0.05, 0.05, 0.07), 0.72)
        var skin_dark := A.mat("seat")

        # ---- torso parts (positions/basis set every frame by rider.gd)
        var pelvis := _seg(parent)
        var pm := A.capsule(pelvis, Vector3.ZERO, 0.078, 0.18, pants_r)
        pm.scale = Vector3(1, 1, 0.8)
        r["pelvis"] = pelvis

        var torso := _seg(parent)
        var tm := A.capsule(torso, Vector3(0, 0.17, 0), 0.098, 0.36, jersey_r)
        tm.scale = Vector3(1, 1, 0.74)
        A.box(torso, Vector3(0.075, 0.20, 0), Vector3(0.035, 0.18, 0.24), A.mat("cone_white"))  # chest protector
        A.box(torso, Vector3(-0.05, 0.20, 0), Vector3(0.03, 0.16, 0.22), A.mat("boot"))         # back pad
        r["torso"] = torso

        var head := _seg(parent)
        var hm := A.sphere(head, Vector3(0.02, 0.05, 0), 0.118, A.helmet_m(helmet_col))
        hm.scale = Vector3(1.0, 1.05, 0.95)
        A.box(head, Vector3(0.115, 0.02, 0), Vector3(0.03, 0.09, 0.15), A.mat("visor"))         # visor
        A.box(head, Vector3(0.105, -0.055, 0), Vector3(0.07, 0.06, 0.13), A.helmet_m(helmet_col))  # chin bar
        A.box(head, Vector3(0.07, 0.035, 0), Vector3(0.05, 0.035, 0.24), A.mat("goggle"))       # goggles strap
        var peak := A.box(head, Vector3(0.10, 0.115, 0), Vector3(0.16, 0.018, 0.20), A.helmet_m(helmet_col))
        peak.rotation = Vector3(0, 0, 0.22)
        r["head"] = head

        # ---- arms (L behind, R in front, shaded differently)
        for side in [["l", -0.10, jersey_l], ["r", 0.10, jersey_r]]:
                var s: String = side[0]
                var zoff: float = side[1]
                var m: StandardMaterial3D = side[2]
                var ua := _seg(parent)
                A.capsule(ua, Vector3(L_UA / 2.0, 0, 0), 0.055, L_UA + 0.06, m)
                ua.position.z = zoff
                var fa := _seg(parent)
                A.capsule(fa, Vector3(L_FA / 2.0, 0, 0), 0.048, L_FA + 0.05, m)
                fa.position.z = zoff
                var hand := _seg(parent)
                A.sphere(hand, Vector3.ZERO, 0.056, A.mat("glove"))
                hand.position.z = zoff
                A.cyl(hand, Vector3(-0.05, 0, 0), 0.05, 0.07, A.mat("glove"), PI / 2)
                r["ua_" + s] = ua
                r["fa_" + s] = fa
                r["hand_" + s] = hand

        # ---- legs
        for side in [["l", -0.075, pants_l], ["r", 0.075, pants_r]]:
                var s: String = side[0]
                var zoff: float = side[1]
                var m: StandardMaterial3D = side[2]
                var th := _seg(parent)
                A.capsule(th, Vector3(L_TH / 2.0, 0, 0), 0.085, L_TH + 0.08, m)
                th.position.z = zoff
                var sh := _seg(parent)
                A.capsule(sh, Vector3(L_SH / 2.0, 0, 0), 0.06, L_SH + 0.06, m)
                sh.position.z = zoff
                A.cyl(sh, Vector3(L_SH - 0.05, 0, 0), 0.063, 0.12, A.mat("boot"))     # boot upper
                var foot := _seg(parent)
                A.box(foot, Vector3(0.045, -0.02, 0), Vector3(0.21, 0.085, 0.10), A.mat("boot"))
                foot.position.z = zoff
                r["th_" + s] = th
                r["sh_" + s] = sh
                r["foot_" + s] = foot

        r["len"] = {"ua": L_UA, "fa": L_FA, "th": L_TH, "sh": L_SH}
        return r

func _seg(parent: Node3D) -> Node3D:
        var n := Node3D.new()
        parent.add_child(n)
        return n
