extends CanvasLayer
## In-game HUD: stunt seconds timer (top center), score panel (top left),
## touch controls (left: driving, right: tricks with tabs), crash overlay,
## record banner, toasts. Fully multitouch.

signal pause_pressed

const UIB := preload("res://scripts/ui/ui_builder.gd")

var timer_lbl: Label
var caption_lbl: Label
var map_lbl: Label
var best_lbl: Label
var score_lbl: Label
var mult_lbl: Label
var pending_lbl: Label
var speed_lbl: Label
var toasts: VBoxContainer
var crash_box: VBoxContainer
var crash_reason: Label
var crash_pen: Label
var record_banner: Label
var tab_bar: HBoxContainer
var trick_root: Control
var tab_btns := []
var trick_wraps := {}   # action -> Node2D
var drive_wraps := {}   # action -> Node2D
var cur_tab := 0
var _rec_pulse := 0.0

func _ready() -> void:
        process_mode = Node.PROCESS_MODE_ALWAYS
        layer = 10
        _build_top()
        _build_score()
        _build_controls()
        _build_overlays()
        apply_btn_settings()
        GameState.settings_changed.connect(apply_btn_settings)

func _v() -> Vector2:
        return get_viewport().get_visible_rect().size

func _place(c: Control, ax: float, ay: float, l: float, t: float, r: float, b: float) -> void:
        c.anchor_left = ax
        c.anchor_right = ax
        c.anchor_top = ay
        c.anchor_bottom = ay
        c.offset_left = l
        c.offset_top = t
        c.offset_right = r
        c.offset_bottom = b

# ------------------------------------------------------------- top timer
func _build_top() -> void:
        var box := VBoxContainer.new()
        box.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(box)
        _place(box, 0.5, 0.0, -320, 6, 320, 220)
        timer_lbl = UIB.label("0:00.0", 84, Color(1, 1, 1))
        box.add_child(timer_lbl)
        caption_lbl = UIB.label("СЕКУНД СТАНТА", 26, Color(0.85, 0.93, 1.0))
        box.add_child(caption_lbl)
        map_lbl = UIB.label("", 22, Color(0.9, 0.9, 0.9, 0.9), 4)
        box.add_child(map_lbl)
        best_lbl = UIB.label("", 22, Color(1.0, 0.85, 0.4), 4)
        box.add_child(best_lbl)

func _build_score() -> void:
        var p := UIB.panel(Color(0.1, 0.14, 0.2, 0.35), Color(1, 1, 1, 0.3), 16)
        p.position = Vector2(14, 12)
        add_child(p)
        var v := VBoxContainer.new()
        p.add_child(v)
        score_lbl = UIB.label("ОЧКИ 0", 34)
        v.add_child(score_lbl)
        mult_lbl = UIB.label("×1", 26, Color(0.55, 0.9, 1.0))
        v.add_child(mult_lbl)
        pending_lbl = UIB.label("", 22, Color(0.8, 1.0, 0.8), 4)
        v.add_child(pending_lbl)
        speed_lbl = UIB.label("0 км/ч", 20, Color(0.9, 0.9, 0.9, 0.8), 4)
        v.add_child(speed_lbl)

        toasts = VBoxContainer.new()
        toasts.position = Vector2(14, 170)
        add_child(toasts)

# ------------------------------------------------------------- controls
func _build_controls() -> void:
        var menu_b := UIB.button("МЕНЮ", 30, func(): pause_pressed.emit())
        menu_b.position = Vector2(14, _v().y - 76)
        menu_b.custom_minimum_size = Vector2(130, 62)
        add_child(menu_b)

        var defs := [
                ["gas", "ГАЗ", Vector2(160, 900), 100],
                ["brake_f", "ПЕРЕДНИЙ\nТОРМОЗ", Vector2(115, 730), 76],
                ["brake_r", "ЗАДНИЙ\nТОРМОЗ", Vector2(285, 730), 76],
                ["lean_l", "НАКЛОН ←", Vector2(115, 565), 68],
                ["lean_r", "НАКЛОН →", Vector2(285, 565), 68],
                ["wheelie", "ВИЛЛИ", Vector2(115, 415), 66],
                ["drift", "ДРИФТ", Vector2(285, 415), 62],
                ["do_reset", "СБРОС", Vector2(120, 285), 48],
        ]
        for d in defs:
                var w := UIB.touch_btn(d[0], d[1], d[3], 0.5)
                w.position = d[2]
                add_child(w)
                drive_wraps[d[0]] = w

        trick_root = Control.new()
        trick_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
        trick_root.set_anchors_preset(Control.PRESET_FULL_RECT)
        add_child(trick_root)
        tab_bar = HBoxContainer.new()
        tab_bar.add_theme_constant_override("separation", 8)
        add_child(tab_bar)
        _place(tab_bar, 1.0, 0.0, -566, 14, -14, 74)
        for i in range(TrickData.TABS.size()):
                var tb := UIB.button(String(TrickData.TABS[i]["label"]), 24, _set_tab.bind(i), Color(0.07, 0.11, 0.18, 0.62))
                tb.custom_minimum_size = Vector2(176, 54)
                tab_bar.add_child(tb)
                tab_btns.append(tb)
        _set_tab(0)

func _set_tab(i: int) -> void:
        cur_tab = i
        for c in trick_root.get_children():
                c.queue_free()
        trick_wraps.clear()
        var actions: Array = TrickData.TABS[i]["actions"]
        var cx := _v().x - 220
        var cols := 3
        for idx in range(actions.size()):
                var col := idx % cols
                var row := floori(float(idx) / float(cols))
                var act: String = actions[idx]
                var txt: String = TrickData.TRICK_LABELS.get(act, act)
                var w := UIB.touch_btn(act, txt, 66, 0.5)
                w.position = Vector2(cx - col * 156, 210 + row * 156)
                trick_root.add_child(w)
                trick_wraps[act] = w
        for j in range(tab_btns.size()):
                if j == i:
                        tab_btns[j].modulate = Color(1.25, 1.25, 1.25, 1.0)
                else:
                        tab_btns[j].modulate = Color(0.9, 0.9, 0.9, 0.95)

func apply_btn_settings() -> void:
        var s := float(GameState.settings["btn_scale"])
        var a := float(GameState.settings["btn_alpha"])
        for d in [drive_wraps, trick_wraps]:
                for k in d.keys():
                        var w: Node2D = d[k]
                        var b: TouchScreenButton = w.get_meta("tsb")
                        var r := _base_radius(k) * s
                        b.scale = Vector2.ONE * (r * 2.0 / 160.0)
                        b.position = Vector2(-r, -r)
                        b.modulate = Color(1, 1, 1, clampf(a * 0.55 + 0.15, 0.2, 1.0))
                        var l: Label = w.get_meta("lbl")
                        l.position = Vector2(-r, -r)
                        l.size = Vector2(r * 2.0, r * 2.0)
                        l.add_theme_font_size_override("font_size", int(r * 0.34))

func _base_radius(act: String) -> float:
        match act:
                "gas": return 100.0
                "brake_f", "brake_r": return 76.0
                "lean_l", "lean_r": return 68.0
                "wheelie": return 66.0
                "drift": return 62.0
                "do_reset": return 48.0
                _: return 66.0

# ------------------------------------------------------------- overlays
func _build_overlays() -> void:
        crash_box = VBoxContainer.new()
        crash_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
        add_child(crash_box)
        _place(crash_box, 0.5, 0.5, -330, -130, 330, 130)
        crash_box.visible = false
        var t1 := UIB.label("ПАДЕНИЕ!", 72, Color(1.0, 0.4, 0.35))
        crash_box.add_child(t1)
        crash_reason = UIB.label("", 34)
        crash_box.add_child(crash_reason)
        crash_pen = UIB.label("", 30, Color(1.0, 0.6, 0.5))
        crash_box.add_child(crash_pen)

        record_banner = UIB.label("", 64, Color(1.0, 0.85, 0.25))
        add_child(record_banner)
        _place(record_banner, 0.5, 0.5, -420, -230, 420, -130)
        record_banner.visible = false
        record_banner.pivot_offset = Vector2(420, 50)

# ------------------------------------------------------------- updates
func set_map_info(map_name: String, best_time: float) -> void:
        map_lbl.text = "Карта %s · Версия %d" % [map_name, GameState.VERSION]
        if best_time > 0.0:
                best_lbl.text = "Рекорд: %s" % _fmt(best_time)
        else:
                best_lbl.text = "Рекорд: —"

func update_timer(t: float, active: bool) -> void:
        timer_lbl.text = _fmt(t)
        if active:
                timer_lbl.add_theme_color_override("font_color", Color(0.55, 1.0, 0.75))
        else:
                timer_lbl.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))

func update_score(total: int, mult: int, pending: int) -> void:
        score_lbl.text = "ОЧКИ %d" % total
        if mult > 1:
                mult_lbl.text = "×%d" % mult
        else:
                mult_lbl.text = "×1"
        if pending > 0:
                pending_lbl.text = "серия: %d" % pending
        else:
                pending_lbl.text = ""

func update_speed(kmh: float) -> void:
        speed_lbl.text = "%d км/ч" % int(kmh)

@warning_ignore("integer_division")
func _fmt(t: float) -> String:
        var s := int(floor(t))
        var d := int((t - float(s)) * 10.0)
        return "%d:%02d.%d" % [s / 60, s % 60, d]

func toast(text: String, color: Color) -> void:
        var l := UIB.label(text, 26, color)
        toasts.add_child(l)
        if toasts.get_child_count() > 4:
                var first := toasts.get_child(0)
                toasts.remove_child(first)
                first.queue_free()
        var tw := create_tween()
        tw.tween_interval(1.8)
        tw.tween_property(l, "modulate:a", 0.0, 0.5)
        tw.tween_callback(l.queue_free)

func show_crash(reason: String, lost: int) -> void:
        crash_reason.text = reason
        if lost > 0:
                crash_pen.text = "Серия потеряна  −%d очков" % lost
        else:
                crash_pen.text = "Серия потеряна"
        crash_box.visible = true

func hide_crash() -> void:
        crash_box.visible = false

func flash_record_live() -> void:
        toast("РЕКОРДНЫЙ СТАНТ ИДЁТ!", Color(1.0, 0.85, 0.3))
        _pulse_banner("РЕКОРД!", 0.8)

func show_record(t: float) -> void:
        _pulse_banner("НОВЫЙ РЕКОРД!  %s СЕКУНД" % _fmt(t), 2.4)
        AudioMan.record()

func _pulse_banner(text: String, dur: float) -> void:
        record_banner.text = text
        record_banner.visible = true
        record_banner.modulate.a = 1.0
        record_banner.scale = Vector2(0.6, 0.6)
        var tw := create_tween()
        tw.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
        tw.tween_property(record_banner, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
        tw.tween_interval(dur)
        tw.tween_property(record_banner, "modulate:a", 0.0, 0.4)
        tw.tween_callback(func(): record_banner.visible = false)

func highlight_buttons() -> void:
        # pressed feedback for drive buttons via action state
        for k in drive_wraps.keys():
                var w: Node2D = drive_wraps[k]
                var b: TouchScreenButton = w.get_meta("tsb")
                var on := Input.is_action_pressed(k)
                var l: Label = w.get_meta("lbl")
                l.add_theme_color_override("font_color", Color(0.75, 1.0, 1.0) if on else Color(1, 1, 1, 0.95))
        for k in trick_wraps.keys():
                var w2: Node2D = trick_wraps[k]
                var on2 := Input.is_action_pressed(k)
                var l2: Label = w2.get_meta("lbl")
                l2.add_theme_color_override("font_color", Color(0.75, 1.0, 1.0) if on2 else Color(1, 1, 1, 0.95))
